import sys, os, os.path
import datetime, time
import logging
import configparser
import psycopg2, psycopg2.extras
from psycopg2 import sql
from .mylib import *
import jdatetime
#========================================================

class DataAccess:

    conf = {}


    def __init__(self , dbConn):
        self.dbConn = dbConn
        self.updateConf()
    # Get a connection to the database.
    def getConnElect(self):
        try:
            return self.dbConn.getConn()
        except Exception as e:
            return False

    def setConf(self):

        self.conf['mainPath'] = getAppDir()
        self.conf['confFilePath'] = self.conf['mainPath'] + '\\main.conf'
        self.conf['logPath'] = self.conf['mainPath'] + '\\main.log'

        confFile = configparser.ConfigParser()
        confFile.read(self.conf['confFilePath'])
        self.conf['fileLogging'] = confFile.getboolean('Main', 'file_logging')

    def updateConf(self):

        self.setConf()

        # File logging:
        if self.conf['fileLogging']:
            logging.basicConfig(filename=self.conf['logPath'],
                format='%(asctime)s | %(levelname)s | %(message)s', level=logging.INFO)
        else:
            logging.disable()

    def getInquiryList(self, roleNames):
        try:
            cur = self.getConnElect().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                SELECT
                    smgeometry, letter_number, letter_date , date, project_name, name, address, phone, status, inquiry_response,
                    t5.*
                FROM
                    frontage_inquiry
                LEFT JOIN ({}) t5 ON (t5.smid = frontage_inquiry.smid)
                WHERE frontage_inquiry.smid IN (
                    SELECT inq_id FROM inq_user iu1 WHERE
                    role_name IN %s
                    AND
                    (
                        NOT EXISTS (SELECT * FROM inq_user iu3 WHERE iu3.inq_id = iu1.inq_id AND note1 <> 'owner')
                        OR EXISTS  (SELECT * FROM inq_user iu2 WHERE iu2.inq_id = iu1.inq_id AND note1 = 'sent' AND note2 IS NULL)
                    )
                    AND frontage_inquiry.smid NOT IN (select inq_id from inq_workflow iw where iw.msg like %s)
                )
                ORDER BY smid DESC
                """.format(self.getInqStats()), (tuple(roleNames), '%حقوق%'))
            rows = cur.fetchall()
            return rows
        except Exception as e:
            print(e)
            return False

    def getInquiryListArchive(self):
        try:
            cur = self.getConnElect().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                SELECT
                    smgeometry, letter_number, letter_date , date, project_name, name, address, phone, status, inquiry_response,
                    t5.*
                FROM
                    frontage_inquiry
                LEFT JOIN ({}) t5 ON (t5.smid = frontage_inquiry.smid)
                WHERE frontage_inquiry.smid NOT IN (
                    SELECT inq_id FROM inq_user iu1 WHERE
                    note1 = 'sent' AND note2 IS NULL
                )
                AND frontage_inquiry.smid NOT IN (
                    SELECT inq_id FROM inq_user GROUP BY inq_id HAVING (count(*) = 1)
                )
                ORDER BY frontage_inquiry.smid DESC
                """.format(self.getInqStats()))
            rows = cur.fetchall()
            return rows
        except Exception as e:
            print(e)
            return False

    def getOneInquiry(self, smid):
        try:
            cur = self.getConnElect().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                SELECT
                    *,
                    ST_AsGeoJSON(smgeometry) :: json->'coordinates' AS points
                FROM
                    frontage_inquiry
                WHERE
                    smid = %s
                """, (smid,))
            data = cur.fetchone()
            return data
        except Exception as e:
            print(e)
            return False

    def addNewInq(self, info):
        cur = self.getConnElect().cursor()
        query = "INSERT INTO frontage_inquiry ( " + info['geom_fld'] + ", letter_number , letter_date , date, project_name, name, address, phone, status, inquiry_response, natcode, province) VALUES (ST_GeomFromText('"+info['smgeometry']+"',"+str(QgsProject.instance().crs().postgisSrid())+"), '"+info['letter_number']+"', '"+info['letter_date']+"' ,'"+info['date']+"', '"+info['project_name']+"', '"+info['name']+"', '"+info['address']+"', '"+info['phone']+"', '"+info['status']+"', '"+info['inquiry_response']+"', '"+info['province']+"', '"+info['natcode']+"') RETURNING smid"
        cur.execute(query)
        lastId = cur.fetchone()[0]
        return lastId

    def updateInq(self , info):
        cur = self.getConnElect().cursor()
        query = "UPDATE frontage_inquiry SET {geom_fld} = ST_SetSRID(ST_GeomFromText('{geom}'),{srid}), letter_number = '{let_num}', letter_date = '{let_date}', date = '{date}', project_name = '{proj_nam}' , name = '{name}', address = '{addr}', phone = '{phone}', status = '{stat}', inquiry_response = '{inq_res}', natcode = '{natcod}', province = '{province}' WHERE smid = {smid} RETURNING smid;".format(geom_fld=info['geom_fld'],geom=info['smgeometry'],let_num=info['letter_number'],let_date=info['letter_date'], date = info['date'] , proj_nam=info['project_name'], name=info['name'],addr=info['address'] , phone=info['phone'] , stat=info['status'] , inq_res=info['inquiry_response'] , natcod=info['natcode'] , province = info['province'] , smid=info['smid'],srid=info['geom_srid'])
        cur.execute(query)
        smid = cur.fetchone()[0]
        return smid
    
    def readInqData(self , smid):
        cur = self.getConnElect().cursor()
        
        query = """SELECT letter_number , name , letter_date , natcode , project_name , province , address , phone ,
                 ST_AsGeoJSON(CASE
                                WHEN smgeometry IS NOT NULL THEN smgeometry
                                WHEN smgeometry1 IS NOT NULL THEN smgeometry1
                                WHEN smgeometry2 IS NOT NULL THEN smgeometry2
                            END):: json->'coordinates' FROM frontage_inquiry WHERE smid = {}""".format(smid)
        cur.execute(query)
        result = cur.fetchone()
        return result
     
    def delInq(self, smid):
        try:
            cur = self.getConnElect().cursor()
            query = sql.SQL("""
                    DELETE FROM frontage_inquiry
                    WHERE smid = %s;
                    DELETE FROM inq_user
                    WHERE inq_id = %s;
                """)
            cur.execute(query, (smid, smid,))
            return True
        except Exception as e:
            print(e)
            return False

    def editInq(self, info):
        geo = info['smgeometry']
        del info['smgeometry']
        try:
            cur = self.getConnElect().cursor()
            query = sql.SQL("UPDATE {tableName} SET {data} WHERE {cond} = {conVal}").format(
                tableName = sql.Identifier('frontage_inquiry'),
                cond = sql.Identifier('smid'),
                data = sql.SQL(', ').join(
                    sql.Composed([sql.Identifier(k), sql.SQL(" = "), sql.Placeholder(k)]) for k in info.keys()
                ),
                conVal = sql.Placeholder('smid')
            )
            cur.execute(query, info)
            query = sql.SQL(
                "UPDATE frontage_inquiry SET smgeometry = ST_MakePolygon(ST_GeomFromText(%s)) WHERE smid = %s")
            cur.execute(query, (geo, info['smid'],))

            return True
        except Exception as e:
            print(e)
            return False

    def getAllRoles(self):
        try:
            cur = self.getConnElect().cursor()
            cur.execute("""
                SELECT
                    groname AS name
                FROM
                    pg_catalog.pg_group
                WHERE
                    groname NOT LIKE 'pg_%'
                UNION ALL
                SELECT
                    usename AS name
                FROM
                    pg_catalog.pg_user
                """)
            rows = [r[0] for r in cur.fetchall()]
            return rows
        except Exception as e:
            logging.error(e)
            return False

    def getAllUsers(self):
        try:
            cur = self.getConnElect().cursor()
            cur.execute("""
                SELECT
                    usename AS name
                FROM
                    pg_catalog.pg_user
                """)
            rows = [r[0] for r in cur.fetchall()]
            return rows
        except Exception as e:
            logging.error(e)
            return False

    def getAllGroups(self):
        try:
            cur = self.getConnElect().cursor()
            cur.execute("""
                SELECT
                    groname AS name
                FROM
                    pg_catalog.pg_group
                WHERE
                    groname NOT LIKE 'pg_%'
                """)
            rows = [r[0] for r in cur.fetchall()]
            return rows
        except Exception as e:
            logging.error(e)
            return False

    def getUserGroups(self, userName):
        try:
            cur = self.getConnElect().cursor()
            cur.execute("""
                SELECT
                    rolname
                FROM
                    pg_user
                JOIN pg_auth_members ON
                    (pg_user.usesysid = pg_auth_members.member)
                JOIN pg_roles ON
                    (pg_roles.oid = pg_auth_members.roleid)
                WHERE
                    pg_user.usename = %s;
                """, (userName,))
            rows = [r[0] for r in cur.fetchall()]
            return rows
        except Exception as e:
            return False

    def newInqUser(self, inqId, roleName, note1, note2):
        try:
            cur = self.getConnElect().cursor()
            cur.execute("""
                INSERT INTO inq_user 
                VALUES (DEFAULT, %s, %s, %s, %s, %s)
                ON CONFLICT (inq_id, role_name, note1) DO UPDATE SET note2 = %s
                """, (inqId, roleName, note1, note2, datetime.datetime.now(), note2))
            return True
        except Exception as e:
            print(e)
            return False

    def getInqStats(self):
        return """
                SELECT
                    smid,
                    t1.OWNER, t1.created_at AS date_created,
                    COALESCE(t3.yes, 0) AS yes, COALESCE(t3.no, 0) AS no, COALESCE(t3.waiting, 0) AS waiting
                FROM
                    frontage_inquiry fi
                LEFT JOIN (
                        SELECT
                            inq_id, role_name AS OWNER, created_at
                        FROM
                            inq_user
                        WHERE
                            note1 = 'owner'
                    ) t1
                    ON
                    (t1.inq_id = fi.smid)
                LEFT JOIN (
                        SELECT
                            inq_id, max(waiting) AS waiting, max(yes) AS yes, max(no) AS no
                        FROM (
                            SELECT
                                inq_id, note1, note2, count(*),
                                CASE WHEN note2 IS NULL THEN count(*) ELSE 0 END AS waiting,
                                CASE WHEN note2 = 'yes' THEN count(*) ELSE 0 END AS yes,
                                CASE WHEN note2 = 'no' THEN count(*) ELSE 0 END AS no
                            FROM
                                inq_user
                            WHERE note1 = 'sent'
                            GROUP BY (inq_id, note1, note2)
                        ) t1
                        GROUP BY inq_id
                    ) t3
                    ON
                    (t3.inq_id = fi.smid)
                ORDER BY smid DESC
                """

    def newInqWorkflow(self, inqId, msg):
        try:
            cur = self.getConnElect().cursor()
            cur.execute("""
                INSERT INTO inq_workflow 
                VALUES (DEFAULT, %s, %s, %s)
                """, (datetime.datetime.now(), inqId, msg,))
            return True
        except Exception as e:
            print(e)
            return False

    def getInqWorkflow(self, inqId):
        try:
            cur = self.getConnElect().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                    SELECT * FROM inq_workflow WHERE inq_id = %s
                """, (inqId,))
            rows = cur.fetchall()
            return rows
        except Exception as e:
            return False
        
    def readLawyerData(self , roleNames):
        try:
            cur = self.getConnElect().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                SELECT
                    smgeometry, letter_number, letter_date , date, project_name, name, address, phone, status, inquiry_response,
                    t5.* , iw.msg
                FROM
                    frontage_inquiry
                INNER JOIN inq_workflow iw on iw.inq_id = frontage_inquiry.smid
                LEFT JOIN ({}) t5 ON (t5.smid = frontage_inquiry.smid)
                WHERE frontage_inquiry.smid IN (
                    SELECT inq_id FROM inq_user iu1 WHERE
                    role_name IN %s
                    AND
                    (
                        NOT EXISTS (SELECT * FROM inq_user iu3 WHERE iu3.inq_id = iu1.inq_id AND note1 <> 'owner')
                        OR EXISTS  (SELECT * FROM inq_user iu2 WHERE iu2.inq_id = iu1.inq_id AND note1 = 'sent' AND note2 IS NULL)
                    )
                )
                and iw.msg like %s
                ORDER BY smid DESC
            """.format(self.getInqStats()), (tuple(roleNames), '%حقوق%'))
            result = cur.fetchall()
            return result
        except Exception as e :
            print(e)
            return False
    
    def getInqSentRoles(self, inqId):
        try:
            cur = self.getConnElect().cursor()
            cur.execute("""
                SELECT
                    role_name
                FROM
                    inq_user
                WHERE
                    inq_id = %s
                    AND note1 = 'sent'
                    AND note2 IS NULL
                """, (inqId,))
            rows = [r[0] for r in cur.fetchall()]
            return rows
        except Exception as e:
            logging.error(e)
            return False
    
    def getSridOfGeometry(self, smid , geom_fld):
        try:
            cur = self.getConnElect().cursor()
            cur.execute("""
                SELECT
                    St_srid({smgeometry})
                FROM
                    frontage_inquiry
                WHERE
                    smid = {smid}
                """.format(smid=smid , smgeometry = geom_fld))
            rows = cur.fetchone()
            return rows[0]
        except Exception as e:
            print(e)
            logging.error(e)
            return False
