# General tools for my own use.

import sys, os, os.path
import time, datetime
import csv
from qgis.core import QgsProject



def strToList(input, delimiter = ','):
    outList = []
    reader = csv.reader(input.split('\n'), delimiter=delimiter)
    for row in reader:
        outList = row
    outList = list(map(str.strip, outList))
    return outList


def listToStr(input, quoteWrap = False):
    if not quoteWrap:
        outStr = ','.join(input)
    else:
        outStr = ','.join(f"'{w}'" for w in input)
    return outStr


# Get path of application directory.
def getAppDir():

    # Determine if application is a script file or frozen exe
    if getattr(sys, 'frozen', False):
        application_path = os.path.dirname(sys.executable)
    elif __file__:
        application_path = os.path.dirname(__file__)

    return application_path


def is_number(n):
    if n is None:
        return False
    try:
        float(n)   # Type-casting the string to `float`.
                   # If string is not a valid `float`, 
                   # it'll raise `ValueError` exception
    except ValueError:
        return False
    return True


def get_layer_by_tablename(tablename):
    layers = QgsProject.instance().mapLayers().values()
    if len(layers) == 0:
        return None
    layer = None
    for cur_layer in layers:
        uri_table = get_layer_source_table_name(cur_layer)
        if uri_table is not None and uri_table == tablename:
            layer = cur_layer
            break
    return layer

def get_layer_source_table_name(layer):
    if layer is None:
        return None
    uri_table = None
    uri = layer.dataProvider().dataSourceUri().lower()
    pos_ini = uri.find('table=')
    pos_end_schema = uri.rfind('.')
    pos_fi = uri.find('" ')
    if pos_ini != -1 and pos_fi != -1:
        uri_table = uri[pos_end_schema+2:pos_fi]
    return uri_table