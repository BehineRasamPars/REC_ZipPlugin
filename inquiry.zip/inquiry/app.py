import sys, os, os.path
from .mylib import *
sys.path.insert(1, getAppDir() + '/packages')
import datetime, time
from typing import TYPE_CHECKING
from PyQt5 import QtWidgets, QtGui, uic, QtCore
from qgis.core import QgsProject
from qgis.PyQt.QtWidgets import QAction, QFileDialog
from qgis.utils import iface
from psycopg2.sql import NULL
from .resources import *
from .gui_add_new import Ui_NewRecord
from .gui_inquiry import Ui_MainWindow
from .gui_workflow import Ui_workflow
from .gui_manage_dest import Ui_MainWindow as Ui_ManageDest
import jdatetime
import xlwt
import pyproj
from shapely import wkb
#========================================================

class Inquiry_GUI(QtWidgets.QMainWindow):

    dataAccess = None
    data = None
    pathList = []
    currTable = ''
    winAddNew = QtWidgets.QDialog()
    winUpdate = QtWidgets.QDialog()
    winManage = QtWidgets.QMainWindow()
    winWorkflow = QtWidgets.QDialog()
    currSmid = 0
    currUser = None
    currGroups = None
    tab_source = 0
    ui_newr = None
    ui_update = None


    def __init__(self , curUser , dataAccess):
        super().__init__()
        self.dataAccess = dataAccess
        self.currUser = curUser
        self.currGroups = self.dataAccess.getUserGroups(self.currUser)
        self.province_srid = self.dataAccess.getSridOfGeometry()
        self.initUI()

    def initUI(self):

        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        # self.setFixedSize(self.size())
        self.setWindowIcon(QtGui.QIcon(f'{getAppDir()}/gui/icons/app.png'))
        self.ui.send_btn.setIcon(QtGui.QIcon(f'{getAppDir()}/gui/icons/send.png'))
        self.statusLabel = QtWidgets.QLabel('')
        self.statusLabel.setAlignment(QtCore.Qt.AlignRight)
        self.ui.statusbar.addWidget(self.statusLabel)

        self.ui.username.setText(self.currUser)
        self.ui.groupNames.setText(listToStr(self.currGroups))
        self.ui.newRecord.clicked.connect(self.newRecord)
        self.ui.refresh.clicked.connect(self.updateWindow)
        self.ui.refresh2.clicked.connect(self.updateWindow)
        self.ui.manage_dest_btn.clicked.connect(self.manageDestination)
        self.ui.refreshAll.clicked.connect(self.updateWindow)
        self.ui.inqList.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.ui.searchBarArchieve.textChanged.connect(self.search_inqlist2)
        self.ui.searchBarMain.textChanged.connect(self.search_inqlist)
        self.ui.searchBarAll.textChanged.connect(self.search_listAll)
        self.ui.inqList2.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.ui.inqListAll.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.ui.inqList.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.ui.inqList2.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.ui.inqListAll.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.ui.excelOut.clicked.connect(self.excelOutFun)
        self.ui.excelOutAll.clicked.connect(self.excelOutFun)
        self.ui.inqList.itemSelectionChanged.connect(self.changeSendCMBStatus)
        self.ui.send_btn.clicked.connect(self.sendInquiryToDest)
        
        self.ui.inqList.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.ui.inqList.customContextMenuRequested.connect(self.generateMenu)
        self.ui.inqList.viewport().installEventFilter(self)

        self.ui.inqList2.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.ui.inqList2.customContextMenuRequested.connect(self.generateMenu2)
        self.ui.inqList2.viewport().installEventFilter(self)
        self.ui.inqListAll.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.ui.inqListAll.customContextMenuRequested.connect(self.generateMenu3)
        self.ui.inqListAll.viewport().installEventFilter(self)
        self.checkUserAdmin()
        self.fillSendToCMB()
        self.show()
        self.updateWindow()

    def newRecord(self):
        self.ui_newr = Ui_NewRecord()
        self.ui_newr.setupUi(self.winAddNew)
        self.ui_newr.submit.clicked.connect(self.newRecordSubmit)
        self.ui_newr.addCoord.clicked.connect(lambda : self.newCoord(self.ui_newr))
        self.ui_newr.getGeoFromMap.clicked.connect(lambda : self.getGeoFromMap(self.ui_newr))
        self.ui_newr.tabWidget.tabBar().installEventFilter(self)
        self.winAddNew.show()
        self.ui_newr.coords.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch)

    def fillSendToCMB(self):
        dest_group_list = self.dataAccess.getUsersFriends(self.currUser, 'Group', self.is_super_user)
        dest_user_list = self.dataAccess.getUsersFriends(self.currUser, 'User', self.is_super_user)
        self.ui.sendToCMB.addItems(dest_group_list)
        self.ui.sendToCMB.insertSeparator(len(dest_group_list))
        self.ui.sendToCMB.addItems(dest_user_list)

    def checkUserAdmin(self):
        self.is_super_user = self.dataAccess.checkIsSuperUser(self.currUser)
        self.ui.manage_dest_btn.setEnabled(self.is_super_user) 
        self.ui.excelOutAll.setEnabled(self.is_super_user)

    def updateRecord(self):
        self.ui_update = Ui_NewRecord()
        self.ui_update.setupUi(self.winUpdate)
        self.fill_value_to_update_form()
        self.ui_update.submit.clicked.connect(self.updateRecordSubmit)
        self.ui_update.addCoord.clicked.connect(lambda : self.newCoord(self.ui_update))
        self.ui_update.getGeoFromMap.clicked.connect(lambda : self.getGeoFromMap(self.ui_update))
        self.ui_update.tabWidget.tabBar().installEventFilter(self)
        self.winUpdate.show()
        self.ui_update.coords.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch)

    def manageDestination(self):
        self.ui_manage = Ui_ManageDest()
        self.ui_manage.setupUi(self.winManage)
        self.winManage.setWindowFlags(self.winManage.windowFlags() | QtCore.Qt.CustomizeWindowHint)
        self.winManage.setWindowFlags(self.winManage.windowFlags() & ~QtCore.Qt.WindowMaximizeButtonHint)
        self.accessComboBoxes()
        self.ui_manage.save_user_access_btn.clicked.connect(lambda : self.saveUserAccess('User'))
        self.ui_manage.save_group_access_btn.clicked.connect(lambda : self.saveUserAccess('Group'))
        self.ui_manage.selfOwner_CMB.currentIndexChanged.connect(lambda: self.sourceUserChanged('User'))
        self.ui_manage.gselfOwner_CMB.currentIndexChanged.connect(lambda: self.sourceUserChanged('Group'))
        self.winManage.show()

    def accessComboBoxes(self):
        self.allUser = self.dataAccess.getAllUsers()
        self.allGroup = self.dataAccess.getAllGroups()
        self.fillUsersAccessSource()
        self.fillUsersAccessDest()
    
    def fillUsersAccessSource(self):
        for eachUser in self.allUser :
            self.ui_manage.selfOwner_CMB.addItem(eachUser)
            self.ui_manage.gselfOwner_CMB.addItem(eachUser)

    def fillUsersAccessDest(self):
        self.fillSelectedDest(self.ui_manage.otherOwner_CMB, self.ui_manage.selfOwner_CMB , 'User', self.allUser)
        self.fillSelectedDest(self.ui_manage.gotherOwner_CMB, self.ui_manage.gselfOwner_CMB, 'Group',self.allGroup)


    def fillSelectedDest(self, destObjectName, sourceNameObject, destType,  allDest):
        destObjectName.clear()
        if allDest:
            for eachUser in allDest:
                destObjectName.addItem(eachUser)
        destObjectName.removeItem(destObjectName.findText(sourceNameObject.currentText()))
        all_dest_result = self.dataAccess.getUsersFriends(sourceNameObject.currentText(), destType, None)
        for each_dest in all_dest_result:
            ind = destObjectName.findText(each_dest)
            item = destObjectName.model().item(ind, 0)
            if item:
                item.setCheckState(QtCore.Qt.Checked)

    def saveUserAccess(self, dest_type):
        source_user = self.ui_manage.selfOwner_CMB if dest_type == 'User' else self.ui_manage.gselfOwner_CMB
        dest_object = self.ui_manage.otherOwner_CMB if dest_type == 'User' else self.ui_manage.gotherOwner_CMB
        current_user_friends_access = self.dataAccess.getUsersFriends(source_user.currentText(), dest_type, None)
        new_users = []
        self.dataAccess.getConnElect().autocommit = False
        for a_p in dest_object.checkedItems():
            new_users.append(a_p.strip())
        
        for a_cur_user in current_user_friends_access:
            if not a_cur_user in new_users:
                self.dataAccess.RemoveUsersFriends(source_user.currentText(),a_cur_user,dest_type)
        
        for a_new_user in new_users:
            if not a_new_user in current_user_friends_access:
                self.dataAccess.AddUsersFriends(source_user.currentText(),a_new_user,dest_type)
        self.dataAccess.getConnElect().commit()
        self.dataAccess.getConnElect().autocommit = True

    def sourceUserChanged(self, dest_type):
        source_user = self.ui_manage.selfOwner_CMB if dest_type == 'User' else self.ui_manage.gselfOwner_CMB
        dest_object = self.ui_manage.otherOwner_CMB if dest_type == 'User' else self.ui_manage.gotherOwner_CMB
        all_dest = self.allUser if dest_type == 'User' else self.allGroup
        self.fillSelectedDest(dest_object, source_user, dest_type, all_dest) 

    def fill_value_to_update_form(self):
        self.ui_update.smid = self.ui.inqList.item(self.ui.inqList.currentRow(), 0).text()
        result = self.dataAccess.readInqData(self.ui_update.smid)
        self.ui_update.letter_number.setText(result[0]) 
        self.ui_update.name.setText(result[1]) 
        self.ui_update.letter_date.setText(result[2]) 
        self.ui_update.natcode.setText(result[3]) 
        self.ui_update.project.setText(result[4]) 
        self.ui_update.province.setText(result[5]) 
        self.ui_update.addr.setText(result[6]) 
        self.ui_update.phone.setText(result[7])
        result1 = self.normalize_nested_lists(result[8])
        cmb_index = self.checkSMBIndex(result1)
        self.ui_update.geomType_CMB.setCurrentIndex(cmb_index) 
        self.ui_update.geomType_CMB.setEnabled(False) 
        self.fill_coord_table(result1)


    def checkSMBIndex(self, data):
        if len(data) == 1 :
            return 3
        elif len(data) == 2 :
            return 2
        else :
            return 1
    
    def fill_coord_table(self , coord_list):
        for each_utm_point in coord_list:
            self.newCoord(self.ui_update , each_utm_point[0] , each_utm_point[1])
 
    def normalize_nested_lists(self , data):
        if isinstance(data, list):
            if all(isinstance(item, list) and len(item) == 2 for item in data):
                return data
            elif all(isinstance(item, int) for item in data):
                return [data]
            elif all(isinstance(item, list) and len(item) == 2 for sublist in data for item in sublist):
                return [item for sublist in data for item in sublist]
        return None
        
    def convert_geometry(self , object_widget):
        if self.tab_source == 0:
            self.convert_utm_to_dms(object_widget)
        elif self.tab_source == 1:
            self.convert_d_to_utm(object_widget)
            self.convert_utm_to_dms(object_widget)
        elif self.tab_source == 2:
            self.convert_dms_to_utm(object_widget)
            self.convert_utm_to_d(object_widget)

    def convert_utm_to_d(self,object_widget):
        easting = object_widget.addX.text()
        northing = object_widget.addY.text()
        if easting and northing:
            projid = int(str(self.province_srid)[-2:])
            utm_proj = pyproj.Proj(proj='utm', zone=projid, ellps='WGS84', datum='WGS84')
            lat, lon = utm_proj(easting, northing, inverse=True)
            self.set_d_input_value(lon , lat , object_widget)
            return lon , lat
        else :
            return None , None


    def convert_utm_to_dms(self , object_widget):
        lon , lat = self.convert_utm_to_d(object_widget)
        # Convert decimal degrees to DMS format
        if lon and lat:
            degrees = int(lon)
            minutes = int((lon - degrees) * 60)
            seconds = (lon - degrees - minutes / 60) * 3600
            lon_dms = (degrees, minutes, seconds)

            degrees = int(lat)
            minutes = int((lat - degrees) * 60)
            seconds = (lat - degrees - minutes / 60) * 3600
            lat_dms = (degrees, minutes, seconds)
            self.set_dms_input_value(lon_dms , lat_dms , object_widget)


    def getGdbName(self):
        projid = QgsProject.instance().crs().authid().split(':')[1][3:]
        return projid

    def convert_to_utm(self , lat , lon):
        if (lat is not None) and (lon is not None):
            try:
                proj_zone = int(str(self.province_srid)[-2:])
                proj_string = "+proj=utm +zone={} +ellps=WGS84 +datum=WGS84 +units=m +no_defs".format(proj_zone)
                utm_proj = pyproj.Proj(proj_string)
                # Convert decimal degrees to UTM
                easting, northing = pyproj.transform(pyproj.Proj("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs"), utm_proj, lat, lon)
                return easting , northing
            except Exception as e:
                print(f"error {e}")        
        else:
            return None , None

    def convert_d_to_utm(self , object_widget):
        lat_d = object_widget.dmd_xd.text()
        lat_dd = object_widget.dmd_xm.text()
        lon_d = object_widget.dmd_yd.text()
        lon_dd = object_widget.dmd_ym.text()
        if lat_d and lat_dd and lon_d and lon_dd:
            lat = '{}.{}'.format(lat_d,lat_dd)
            lon = '{}.{}'.format(lon_d,lon_dd)
            easting , northing = self.convert_to_utm(lat , lon)
            self.set_utm_input_value(easting,northing , object_widget)

    def convert_dms_to_utm(self , object_widget):
        dms_xd = object_widget.dms_xd.text()
        dms_xm = object_widget.dms_xm.text()
        dms_xs = object_widget.dms_xs.text()
        dms_ym = object_widget.dms_ym.text()
        dms_ys = object_widget.dms_ys.text()
        dms_yd = object_widget.dms_yd.text()
        if dms_xd and dms_xm and dms_xs and dms_ym and dms_yd and dms_ys:
            lat = int(dms_xd) + int(dms_xm)/60 + float(dms_xs)/3600
            lon = int(dms_yd) + int(dms_ym)/60 + float(dms_ys)/3600
            easting , northing = self.convert_to_utm(lat , lon)
            self.set_utm_input_value(easting,northing , object_widget)

    def set_d_input_value(self , lon , lat , object_widget):
        object_widget.dmd_xd.setText(str(lat).split('.')[0])
        object_widget.dmd_xm.setText((str(lat).split('.')[1])[:7])
        object_widget.dmd_yd.setText(str(lon).split('.')[0])
        object_widget.dmd_ym.setText((str(lon).split('.')[1])[:7])

    def set_dms_input_value(self , lon_dms , lat_dms , object_widget):
        object_widget.dms_xd.setText(str(lat_dms[0]))
        object_widget.dms_xm.setText(str(lat_dms[1]))
        object_widget.dms_xs.setText((str(lat_dms[2]))[:5])
        object_widget.dms_yd.setText(str(lon_dms[0]))
        object_widget.dms_ym.setText(str(lon_dms[1]))
        object_widget.dms_ys.setText((str(lon_dms[2]))[:5])

    def set_utm_input_value(self , easting , northing , object_widget):
        object_widget.addX.setText(str(easting)[:6])
        object_widget.addY.setText(str(northing)[:7])


    def fillInqList(self , object_widget , inq_value):
            object_widget.setRowCount(len(inq_value))
            for index, item in enumerate(inq_value):
                if item['owner'] == self.currUser:
                    owner = 'شما'
                else:
                    owner = item['owner']
                object_widget.setItem(index, 0, QtWidgets.QTableWidgetItem(str(item['smid'])))
                object_widget.setItem(index, 1, QtWidgets.QTableWidgetItem(str(item['name'])))
                object_widget.setItem(index, 2, QtWidgets.QTableWidgetItem(str(item['project_name'])))
                object_widget.setItem(index, 3, QtWidgets.QTableWidgetItem(item['letter_number']))
                object_widget.setItem(index, 4, QtWidgets.QTableWidgetItem(item['letter_date']))
                date_created = jdatetime.date.fromgregorian(date=item['date_created']).strftime("%Y/%m/%d")
                object_widget.setItem(index, 5, QtWidgets.QTableWidgetItem(date_created))
                object_widget.setItem(index, 6, QtWidgets.QTableWidgetItem(owner))
                object_widget.setItem(index, 7, QtWidgets.QTableWidgetItem(str(item['waiting'])))
                object_widget.setItem(index, 8, QtWidgets.QTableWidgetItem(str(item['yes'])))
                object_widget.setItem(index, 9, QtWidgets.QTableWidgetItem(str(item['no'])))
            object_widget.resizeColumnsToContents()

    def clearList(self , object_widget):
        object_widget.setRowCount(0)
        # object_widget.clear()

    def updateWindow(self):
        self.msgUser('wait')

        inqList = self.dataAccess.getInquiryList([self.currUser] + self.currGroups)
        self.clearList(self.ui.inqList)
        if len(inqList):
            self.fillInqList(self.ui.inqList , inqList)

        inqList = self.dataAccess.getInquiryListArchive()
        if len(inqList):
            self.ui.inqList2.setRowCount(len(inqList))
            for index, item in enumerate(inqList):
                if item['date_created']:
                    date_created = jdatetime.date.fromgregorian(date=item['date_created']).strftime("%d/%m/%Y")
                else:
                    date_created = item['date']
                self.ui.inqList2.setItem(index, 0, QtWidgets.QTableWidgetItem(str(item['smid'])))
                if item['no'] > 0:
                    status = 'رد شده'
                else:
                    status = 'تایید شده'
                if not item['owner']:
                    status = '-'
                self.ui.inqList2.setItem(index, 1, QtWidgets.QTableWidgetItem(status))
                self.ui.inqList2.setItem(index, 2, QtWidgets.QTableWidgetItem(date_created))
                self.ui.inqList2.setItem(index, 3, QtWidgets.QTableWidgetItem(item['letter_number']))
                self.ui.inqList2.setItem(index, 4, QtWidgets.QTableWidgetItem(item['name']))
                self.ui.inqList2.setItem(index, 5, QtWidgets.QTableWidgetItem(item['project_name']))
            self.ui.inqList2.resizeColumnsToContents()
            header = self.ui.inqList2.horizontalHeader()     
            header.setSectionResizeMode(4, QtWidgets.QHeaderView.Stretch)
            header.setSectionResizeMode(5, QtWidgets.QHeaderView.Stretch)
        
        inqList = self.dataAccess.readAllData()
        self.clearList(self.ui.inqListAll)
        if len(inqList):
            self.fillInqList(self.ui.inqListAll , inqList)
        
        self.msgUser('none')

    def generateMenu(self, pos):
        self.menu.exec_(self.ui.inqList.mapToGlobal(pos))

    def eventFilter(self, source, event):
        if(event.type() == QtCore.QEvent.MouseButtonPress and
            event.buttons() == QtCore.Qt.RightButton and
            source is self.ui.inqList.viewport()):
                item = self.ui.inqList.itemAt(event.pos())
                if not item:
                    self.menu = QtWidgets.QMenu(self)
                    return False
                self.currSmid = self.ui.inqList.item(item.row(), 0).text()
                currOwner = self.ui.inqList.item(item.row(), 6).text() == 'شما'
                if item is not None:
                    self.menu = QtWidgets.QMenu(self)
                    self.menu.addAction('نمایش بر روی نقشه', self.showInMap)
                    self.menu.addAction('مشاهده گردش کار', self.workflow)
                    self.menu.addAction('تایید استعلام',
                        lambda val1=self.currUser, val2='sent', val3='yes': self.newInqUser(val1, val2, val3))
                    self.menu.addAction('رد استعلام',
                        lambda val1=self.currUser, val2='sent', val3='no': self.newInqUser(val1, val2, val3))
                    if currOwner:
                        self.menu.addAction('حذف', self.delete)
                        self.menu.addAction('ویرایش', self.updateRecord)

        elif(event.type() == QtCore.QEvent.MouseButtonPress and
            event.buttons() == QtCore.Qt.RightButton and
            source is self.ui.inqList2.viewport()):
                item = self.ui.inqList2.itemAt(event.pos())
                self.currSmid = self.ui.inqList2.item(item.row(), 0).text()
                item = self.ui.inqList2.itemAt(event.pos())
                if not item:
                    self.menu = QtWidgets.QMenu(self)
                    return False
                self.menu = QtWidgets.QMenu(self)
                self.menu.addAction('نمایش بر روی نقشه', self.showInMap)
                self.menu.addAction('مشاهده گردش کار', self.workflow)
        elif(event.type() == QtCore.QEvent.MouseButtonPress and
            event.buttons() == QtCore.Qt.RightButton and
            source is self.ui.inqListAll.viewport()):
                item = self.ui.inqListAll.itemAt(event.pos())
                self.currSmid = self.ui.inqListAll.item(item.row(), 0).text()
                item = self.ui.inqListAll.itemAt(event.pos())
                if not item:
                    self.menu = QtWidgets.QMenu(self)
                    return False
                self.menu = QtWidgets.QMenu(self)
                self.menu.addAction('نمایش بر روی نقشه', self.showInMap)
                self.menu.addAction('مشاهده گردش کار', self.workflow)

        if Ui_NewRecord.__dict__.get('instances'):
            if(event.type() == QtCore.QEvent.MouseButtonPress and self.ui_newr):
                if source == self.ui_newr.tabWidget.tabBar():
                    tabIndex = source.tabAt(event.pos())
                    self.convert_geometry(self.ui_newr)
                    self.tab_source = tabIndex
            if(event.type() == QtCore.QEvent.MouseButtonPress and self.ui_update):
                if source == self.ui_update.tabWidget.tabBar():
                    tabIndex = source.tabAt(event.pos())
                    self.convert_geometry(self.ui_update)
                    self.tab_source = tabIndex
                    


        return super(Inquiry_GUI, self).eventFilter(source, event)

    def changeSendCMBStatus(self):
        current_item = self.ui.inqList.currentRow()
        if current_item != -1:
            current_user = self.ui.inqList.item(current_item, 6).text()
            self.currSmid = self.ui.inqList.item(current_item, 0).text()
            self.ui.sendToCMB.deselectAllOptions()
            if current_user == 'شما':
                self.ui.sendToCMB.setEnabled(True)
                self.ui.send_btn.setEnabled(True)

    def sendInquiryToDest(self):
        for role in self.ui.sendToCMB.checkedItems():
            if role not in [self.currUser] + self.currGroups:
                self.newInqUser(role, 'sent', None)

    def generateMenu2(self, pos):
        self.menu.exec_(self.ui.inqList2.mapToGlobal(pos))

    def generateMenu3(self, pos):
        self.menu.exec_(self.ui.inqListAll.mapToGlobal(pos))
    
    def msgUser(self, type, msg = None): # Send a message to the user. 
        self.statusLabel.setText('')
        if type == 'success':
            msgBox = QtWidgets.QMessageBox()
            msgBox.setIcon(QtWidgets.QMessageBox.Information)
            if not msg:
                msg = "عملیات با موفقیت انجام شد."
            msgBox.setText(msg)
            msgBox.setWindowTitle("موفقیت")
            msgBox.addButton(QtWidgets.QPushButton("باشد"), QtWidgets.QMessageBox.YesRole)
            msgBox.exec_()
        elif type == 'fail':
            msgBox = QtWidgets.QMessageBox()
            msgBox.setIcon(QtWidgets.QMessageBox.Critical)
            if not msg:
                msg = "عملیات با شکست مواجه شد."
            msgBox.setText(msg)
            msgBox.setWindowTitle("شکست")
            msgBox.addButton(QtWidgets.QPushButton("باشد"), QtWidgets.QMessageBox.YesRole)
            msgBox.exec_()
        elif type == 'wait':
            self.statusLabel.setText('لطفا صبر کنید ...')
            self.statusLabel.setStyleSheet('color: rgb(60, 60, 60)')
        elif type == 'none':
            pass
        QtWidgets.qApp.processEvents()

    def checkCoords(self, points , combo_cord):
        selected_type = combo_cord.geomType_CMB.currentIndex()
        if selected_type == 0 or len(points) == 0:
            return False
        elif selected_type == 3 and len(points) != 1:
            return False
        elif selected_type == 2 and len(points) < 2:
            return False
        elif selected_type == 1 and len(points) < 3:
            return False
        return True     

    def updateRecordSubmit(self):
        thePoints = []
        selected_type = self.ui_update.geomType_CMB.currentIndex()     
        try:
            for row in range(self.ui_update.coords.rowCount()):
                thePoints.append(self.ui_update.coords.item(row, 1).text() + ' ' + self.ui_update.coords.item(row, 0).text())
        except:
            pass

        if not self.checkCoords(thePoints , self.ui_update):
            self.msgUser('fail')
            return

        pointsStr = listToStr(thePoints)
        info = {}
        
        if selected_type == 1:
            info['geom_fld'] = 'smgeometry'
            info['smgeometry'] = 'POLYGON(({}))'.format(pointsStr)
        elif selected_type == 2:
            info['geom_fld'] = 'smgeometry1'
            info['smgeometry'] = 'LINESTRING({})'.format(pointsStr)
        else:
            info['geom_fld'] = 'smgeometry2'
            info['smgeometry'] = 'POINT({})'.format(pointsStr)

        info['smid'] = self.ui_update.smid
        info['letter_number'] = self.ui_update.letter_number.text()
        info['letter_date'] = self.ui_update.letter_date.text()
        info['date'] = ''
        info['project_name'] = self.ui_update.project.text()
        info['name'] = self.ui_update.name.text()
        info['address'] = self.ui_update.addr.toPlainText()
        info['phone'] = self.ui_update.phone.text()
        info['province'] = self.ui_update.province.text()
        info['natcode'] = self.ui_update.natcode.text()
        info['status'] = 'درج شده'
        info['inquiry_response'] = 'منتظر پاسخ'

        if not info['letter_number']:
            self.msgUser('fail')
            return
        info['geom_srid'] = self.province_srid
        res1 = self.dataAccess.updateInq(info)
        if res1:
            res2 = self.dataAccess.newInqUser(res1, self.currUser, 'owner', None)
            res3 = self.dataAccess.newInqWorkflow(res1, 'استعلام ویرایش شده توسط {}'.format(self.currUser))
        if res1 and res2 and res3:
            self.msgUser('success')
            self.updateWindow()
            self.winUpdate.close()
        else:
            self.msgUser('fail')

    def newRecordSubmit(self):
        thePoints = []
        selected_type = self.ui_newr.geomType_CMB.currentIndex()     

        try:
            for row in range(self.ui_newr.coords.rowCount()):
                thePoints.append(self.ui_newr.coords.item(row, 1).text() + ' ' + self.ui_newr.coords.item(row, 0).text())
            if selected_type == 1:
                thePoints.append(self.ui_newr.coords.item(0, 1).text() + ' ' + self.ui_newr.coords.item(0, 0).text())
        except:
            pass

        if not self.checkCoords(thePoints , self.ui_newr):
            self.msgUser('fail')
            return

        pointsStr = listToStr(thePoints)
        info = {}
        
        if selected_type == 1:
            info['geom_fld'] = 'smgeometry'
            info['smgeometry'] = 'POLYGON(({}))'.format(pointsStr)
        elif selected_type == 2:
            info['geom_fld'] = 'smgeometry1'
            info['smgeometry'] = 'LINESTRING({})'.format(pointsStr)
        else:
            info['geom_fld'] = 'smgeometry2'
            info['smgeometry'] = 'POINT({})'.format(pointsStr)

        info['letter_number'] = self.ui_newr.letter_number.text()
        info['letter_date'] = self.ui_newr.letter_date.text()
        info['date'] = ''
        info['project_name'] = self.ui_newr.project.text()
        info['name'] = self.ui_newr.name.text()
        info['address'] = self.ui_newr.addr.toPlainText()
        info['phone'] = self.ui_newr.phone.text()
        info['province'] = self.ui_newr.province.text()
        info['natcode'] = self.ui_newr.natcode.text()
        info['status'] = 'درج شده'
        info['inquiry_response'] = 'منتظر پاسخ'
        info['geom_srid'] = self.province_srid

        if not info['letter_number']:
            self.msgUser('fail')
            return
        
        res1 = self.dataAccess.addNewInq(info)
        if res1:
            res2 = self.dataAccess.newInqUser(res1, self.currUser, 'owner', None)
            res3 = self.dataAccess.newInqWorkflow(res1, 'استعلام ایجاد شده توسط {}'.format(self.currUser))
        if res1 and res2 and res3:
            self.msgUser('success')
            self.updateWindow()
            self.winAddNew.close()
        else:
            self.msgUser('fail')

    def newCoord(self,object_widget, x = None, y = None):
        if x == False and y == None:
            x = None
        if not x and x != 0:
            x = object_widget.addX.text()
        if not y and y != 0:
            y = object_widget.addY.text()
        if not is_number(x):
            x = 0
        if not is_number(y):
            y = 0
        rowPosition = object_widget.coords.rowCount()
        object_widget.coords.insertRow(rowPosition)
        object_widget.coords.setItem(rowPosition, 1, QtWidgets.QTableWidgetItem(str(float(x))))
        object_widget.coords.setItem(rowPosition, 0, QtWidgets.QTableWidgetItem(str(float(y))))

    def delete(self):
        smid = self.ui.inqList.item(self.ui.inqList.currentRow(), 0).text()
        if self.dataAccess.delInq(smid):
            self.msgUser('success')
            self.updateWindow()
        else:
            self.msgUser('fail')

    def get_inq_layer(self, smid):
        try:
            cur = self.dataAccess.getConnElect().cursor()
            cur.execute("select st_geometrytype(coalesce(smgeometry,smgeometry1,smgeometry2)) from frontage_inquiry where smid = " + str(smid))
            layer_type = cur.fetchone()[0]
            if layer_type == 'ST_Polygon':
                fld = '(smgeometry)'
            elif layer_type == 'ST_Point':
                fld = '(smgeometry2)'
            else:
                fld = '(smgeometry1)'
            layers = QgsProject.instance().mapLayers()
            for layer_id, layer in layers.items():
                source = layer.source()
                if 'frontage_inquiry' in source and fld in source:
                    return layer

        except Exception as e:
            print(e)

    def search_inqlist(self , search_bar_text):
        for row in range(self.ui.inqList.rowCount()):
            match = False
            for col in range(self.ui.inqList.columnCount()):
                item = self.ui.inqList.item(row, col)
                if search_bar_text.lower() in item.text().lower():
                    match = True
                    break
            self.ui.inqList.setRowHidden(row, not match)

    def search_listAll(self , search_bar_text):
        for row in range(self.ui.inqListAll.rowCount()):
            match = False
            for col in range(self.ui.inqListAll.columnCount()):
                item = self.ui.inqListAll.item(row, col)
                if search_bar_text.lower() in item.text().lower():
                    match = True
                    break
            self.ui.inqListAll.setRowHidden(row, not match)

    def search_inqlist2(self , search_bar_text):
        for row in range(self.ui.inqList2.rowCount()):
            match = False
            for col in range(self.ui.inqList2.columnCount()):
                item = self.ui.inqList2.item(row, col)
                if search_bar_text.lower() in item.text().lower():
                    match = True
                    break
            self.ui.inqList2.setRowHidden(row, not match)

    
    def showInMap(self):
        layer = self.get_inq_layer(self.currSmid)
        layer.deselect(layer.selectedFeatureIds())
        if layer:
            layer.select([int(self.currSmid)])
            iface.setActiveLayer(layer)
            iface.actionZoomToSelected().trigger()

    def workflow(self):
        self.ui_workflow = Ui_workflow()
        self.ui_workflow.setupUi(self.winWorkflow)
        self.winWorkflow.show()
        data = self.dataAccess.getInqWorkflow(self.currSmid)
        self.ui_workflow.table.setRowCount(len(data))
        for index, item in enumerate(data):
            theTime = jdatetime.datetime.fromgregorian(datetime=item['created_at']).strftime("%d/%m/%Y %H:%M:%S")
            self.ui_workflow.table.setItem(index, 0, QtWidgets.QTableWidgetItem(theTime))
            self.ui_workflow.table.setItem(index, 1, QtWidgets.QTableWidgetItem(item['msg']))
        self.ui_workflow.table.resizeColumnsToContents()

    def newInqUser(self, roleName, note1, note2):
        if note1 == 'sent' and note2 == None:
            self.dataAccess.newInqWorkflow(self.currSmid, 'ارسال شده به {}'.format(roleName))
        elif note1 == 'sent' and note2 == 'yes':
            self.dataAccess.newInqWorkflow(self.currSmid, 'تایید شده توسط {}'.format(roleName))
        elif note1 == 'sent' and note2 == 'no':
            self.dataAccess.newInqWorkflow(self.currSmid, 'رد شده توسط {}'.format(roleName))
        if note1 == 'sent' and note2 in ['yes', 'no']:
            inqRoles = self.dataAccess.getInqSentRoles(self.currSmid)
            userRoles = [self.currUser] + self.currGroups
            # commonRole = list(set(inqRoles).intersection(userRoles))

            roleName = self.currUser
        res1 = self.dataAccess.newInqUser(self.currSmid, roleName, note1, note2)
        if res1:
            self.msgUser('success')
            self.updateWindow()
        else:
            self.msgUser('fail')

    def excelOutFun(self):

        filePath = QFileDialog.getSaveFileName(self, 'Save File', '', 'Excel (*.xls)')[0]

        self.msgUser('wait')

        xl = xlwt.Workbook()
        xl_sheet = xl.add_sheet("Sheet1", cell_overwrite_ok=True)
        xl_sheet.cols_right_to_left = True

        for column in range(self.ui.inqList2.columnCount()):
            text = self.ui.inqList2.horizontalHeaderItem(column).text()
            xl_sheet.write(0, column, text)
        for row in range(self.ui.inqList2.rowCount()):
            for column in range(self.ui.inqList2.columnCount()):
                text = self.ui.inqList2.item(row, column).text()
                xl_sheet.write(row + 1, column, text)

        xl.save(filePath)

        self.msgUser('none')
        msgBox = QtWidgets.QMessageBox()
        msg = "خروجی اکسل ذخیره گردید"
        msgBox.setText(msg)
        msgBox.setWindowTitle("موفقیت")
        msgBox.addButton(QtWidgets.QPushButton("باشد"), QtWidgets.QMessageBox.YesRole)
        msgBox.exec_()

    def getGeoFromMap(self , object_widget):
        object_widget.coords.setRowCount(0)
        #try:
        layer = iface.layerTreeView().currentLayer()
        features = layer.selectedFeatures()
        geom = features[0].geometry()
        if layer.geometryType() == 0:
            points = geom.asPoint()
            self.newCoord(object_widget,points.x(), points.y())
        elif layer.geometryType() == 1:
            for point in geom.asMultiPolyline():
                for a_p in point:
                    self.newCoord(object_widget,a_p.x(), a_p.y())
        elif layer.geometryType() == 2:
            for point in geom.asPolygon():
                for a_p in point:
                    self.newCoord(object_widget,a_p.x(), a_p.y())
        object_widget.geomType_CMB.setCurrentIndex(3-layer.geometryType())    
        

        
