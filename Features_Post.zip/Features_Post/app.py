import os
#from .rassam import getAppDir
#os.path.join(rf"{getAppDir()}","\package")
#from typing import TYPE_CHECKING
from PyQt5 import QtWidgets, QtGui
from qgis.core import QgsProject
from qgis.PyQt.QtWidgets import QFileDialog
from qgis.utils import iface
from psycopg2.sql import NULL
from .resources import *
from .gui import *
from .mylib import *
from .DataAccess import DataAccess
import subprocess
from .ExcelOutSample.Conjunction_ColorfulExel_openpyxl import ContainerFunc as EO_ColorfulMonoSheet
from .ExcelOutSample.Conjunction_ColorfulSheetsExel import ContainerFunc as EO_ColorfulSheetBySheet
from .ExcelOutSample.Conjunction_SheetsExel import ContainerFunc as EO_SheetBySheet
from .buffer import Ui_Dialog as BufferDialog
#import xlsxwriter
#========================================================

class Feat_GUI(QtWidgets.QDialog):

    data = None
    pathList = []
    currTable = ''
    bufferSize = 0
    def __init__(self , data_conn):
        self.iface = iface
        super().__init__()
        self.dataAccess = DataAccess(data_conn)
        self.initUI()

    def initUI(self):

        self.ui = Ui_Dialog()
        self.ui.setupUi(self)
        # self.setFixedSize(self.size())
        self.setWindowIcon(QtGui.QIcon(':plugins/Features_Post/gui_icons/app.png'))

        self.ui.mainList.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.ui.mainList.setSortingEnabled(True)
        self.ui.postOrCircuit.currentIndexChanged.connect(self.showPostOrCircuit)
        self.ui.chosenPath.currentIndexChanged.connect(self.pathChanged)
        self.ui.mainList.cellDoubleClicked.connect(self.getNewList)
        self.ui.showInMap.clicked.connect(self.showInMap)
        self.ui.search.textChanged.connect(self.searchNew)
        self.ui.mainList.itemSelectionChanged.connect(self.checkBtnCanEnable)

        self.reportMenu()
        self.excelMenu()
        self.updateWindow()

        self.show()

    def createMenuOnList(self):
        self.ui.mainList.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.ui.mainList.customContextMenuRequested.connect(self.circuteGenerateMenu) # sakhte function generated menu bara har jadval 
        self.ui.mainList.viewport().installEventFilter(self)

    def circuteGenerateMenu(self , pos):
        self.circuteMenu.exec_(self.ui.mainList.mapToGlobal(pos))

    def updateWindow(self):
        pass
        # self.ui.chooseTable.clear()
        # self.ui.chooseTable.addItems(self.dataAccess.getAllTables())

    def msgUser(self, type, msg = None): # Send a message to the user.
        self.ui.footer.setText('')
        if type == 'success':
            msgBox = QtWidgets.QMessageBox()
            msgBox.setIcon(QtWidgets.QMessageBox.Information)
            if not msg:
                msg = "عملیات با موفقیت انجام شد."
            msgBox.setText(msg)
            msgBox.setWindowTitle("موفقیت")
            msgBox.addButton(QtWidgets.QPushButton("باشد"), QtWidgets.QMessageBox.YesRole)
            msgBox.exec_()
        elif type == 'fail':
            msgBox = QtWidgets.QMessageBox()
            msgBox.setIcon(QtWidgets.QMessageBox.Critical)
            if not msg:
                msg = "عملیات با شکست مواجه شد."
            msgBox.setText(msg)
            msgBox.setWindowTitle("شکست")
            msgBox.addButton(QtWidgets.QPushButton("باشد"), QtWidgets.QMessageBox.YesRole)
            msgBox.exec_()
        elif type == 'wait':
            self.ui.footer.setText('لطفا صبر کنید ...')
            self.ui.footer.setStyleSheet('color: rgb(194, 71, 0)')
        elif type == 'none':
            pass
        QtWidgets.qApp.processEvents()

    def showPostOrCircuit(self):

        self.msgUser('wait')
        self.ui.excelReport_TB.setEnabled(False)
        self.ui.showInMap.setEnabled(False)
        self.ui.chosenPath.blockSignals(True)

        if self.ui.postOrCircuit.currentIndex() == 0:
            self.pathList = []
            self.ui.chosenPath.clear()
            self.ui.mainList.clear()
            self.ui.mainList.setColumnCount(0)
            self.ui.mainList.setRowCount(0)

        elif self.ui.postOrCircuit.currentIndex() == 1:
            self.listNew('posts', None)

        elif self.ui.postOrCircuit.currentIndex() == 2:
            self.createMenuOnList()
            self.listNew('circuits', None)
        self.ui.mainList.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch)
        # self.ui.mainList.horizontalHeader().setStretchLastSection(True)

        self.ui.chosenPath.blockSignals(False)

        self.msgUser('none')

    def listNew(self, type, data):
        self.ui.chosenPath.blockSignals(True)
        if type == 'posts':
            self.currTable = 'substat'
            self.emptyMainList()
            self.ui.search.setEnabled(True)
            
            posts = self.dataAccess.getPostList()

            self.pathList = []
            self.pathList.append({ 'type': type, 'data': data })

            self.ui.chosenPath.clear()
            self.ui.chosenPath.addItem('پست ها')

            self.ui.mainList.setRowCount(len(posts))
            self.ui.mainList.setColumnCount(4)
            self.ui.mainList.setHorizontalHeaderItem(0, QtWidgets.QTableWidgetItem('نام'))
            self.ui.mainList.setHorizontalHeaderItem(1, QtWidgets.QTableWidgetItem('کد دیسپاچینگ'))
            self.ui.mainList.setHorizontalHeaderItem(2, QtWidgets.QTableWidgetItem('ظرفیت'))
            self.ui.mainList.setHorizontalHeaderItem(3, QtWidgets.QTableWidgetItem('شناسه'))
            ind = 0
            for post in posts:
                post['subf_name'] = str(post['subf_name']).replace('ك', 'ک')
                post['subf_name'] = str(post['subf_name']).replace('ي', 'ی')
                subst_code_item =  QtWidgets.QTableWidgetItem(str(post['subst_code']))
                subst_code_item.setTextAlignment(QtCore.Qt.AlignHCenter)
                conv_ratio_item =  QtWidgets.QTableWidgetItem(str(post['conv_ratio']))
                conv_ratio_item.setTextAlignment(QtCore.Qt.AlignHCenter)
                smid_item =  QtWidgets.QTableWidgetItem(str(post['smid']))
                smid_item.setTextAlignment(QtCore.Qt.AlignHCenter)
                self.ui.mainList.setItem(ind, 0, QtWidgets.QTableWidgetItem(str(post['subf_name'])))
                self.ui.mainList.setItem(ind, 1, subst_code_item)
                self.ui.mainList.setItem(ind, 2, conv_ratio_item)
                self.ui.mainList.setItem(ind, 3, smid_item)

                ind += 1

        if type == 'circuits':
            self.currTable = 'circuit'
            self.emptyMainList()
            self.ui.search.setEnabled(True)

            circuits = self.dataAccess.getCircuitList()

            self.pathList = []
            self.pathList.append({ 'type': type, 'data': data })

            self.ui.chosenPath.clear()
            self.ui.chosenPath.addItem('مدار ها')

            self.ui.mainList.setRowCount(len(circuits))
            self.ui.mainList.setColumnCount(4)
            self.ui.mainList.setHorizontalHeaderItem(0, QtWidgets.QTableWidgetItem('نام'))
            self.ui.mainList.setHorizontalHeaderItem(1, QtWidgets.QTableWidgetItem('شناسه مدار'))
            self.ui.mainList.setHorizontalHeaderItem(2, QtWidgets.QTableWidgetItem('ولتاژ نامی'))
            self.ui.mainList.setHorizontalHeaderItem(3, QtWidgets.QTableWidgetItem('شناسه'))
            ind = 0
            for circuit in circuits:
                circuit['cir_name'] = str(circuit['cir_name']).replace('ك', 'ک')
                circuit['cir_name'] = str(circuit['cir_name']).replace('ي', 'ی')
                circt_id_item = QtWidgets.QTableWidgetItem(str(circuit['circt_id']))
                circt_id_item.setTextAlignment(QtCore.Qt.AlignHCenter)
                nomi_vol_item = QtWidgets.QTableWidgetItem(str(circuit['nomi_vol']))
                nomi_vol_item.setTextAlignment(QtCore.Qt.AlignHCenter)
                csmid_item = QtWidgets.QTableWidgetItem(str(circuit['smid']))
                csmid_item.setTextAlignment(QtCore.Qt.AlignHCenter)
                self.ui.mainList.setItem(ind, 0, QtWidgets.QTableWidgetItem(str(circuit['cir_name'])))
                self.ui.mainList.setItem(ind, 1, circt_id_item)
                self.ui.mainList.setItem(ind, 2, nomi_vol_item)
                self.ui.mainList.setItem(ind, 3, csmid_item)
                ind += 1

        elif type == 'table-count':
            tableCount = self.dataAccess.getRelatedTables(data['table'], data['idvalue'])
            if tableCount:
                self.currTable = ''
                self.emptyMainList()
                self.pathList.append({ 'type': type, 'data': data })
                self.ui.chosenPath.addItem('انواع عوارض مربوط به: {} به شناسه {}'.format(
                    self.dataAccess.translate(data['table']), data['idvalue']))
                self.ui.chosenPath.setCurrentIndex(self.ui.chosenPath.count() - 1)
                self.ui.mainList.setRowCount(len(tableCount))
                self.ui.mainList.setColumnCount(3)
                self.ui.mainList.setHorizontalHeaderItem(1, QtWidgets.QTableWidgetItem('نام'))
                self.ui.mainList.setHorizontalHeaderItem(2, QtWidgets.QTableWidgetItem('تعداد'))
                self.ui.mainList.setColumnHidden(0, True)
                ind = 0
                for thisTable in tableCount:
                    self.ui.mainList.setItem(ind, 0, QtWidgets.QTableWidgetItem(str(thisTable['table_name'])))
                    self.ui.mainList.setItem(ind, 1, QtWidgets.QTableWidgetItem(
                        str(self.dataAccess.translate(thisTable['table_name']))))
                    self.ui.mainList.setItem(ind, 2, QtWidgets.QTableWidgetItem(str(thisTable['count'])))
                    ind += 1
            else:
                self.msgUser('fail', 'چیزی برای نمایش وجود ندارد')

        elif type == 'other-table':
            ids = self.dataAccess.getTableIds(data['table'], data['con_table'], data['con_idvalue'])
            if ids:
                self.currTable = data['table']
                self.emptyMainList()
                self.pathList.append({ 'type': type, 'data': data })
                self.ui.chosenPath.addItem('عوارض مربوط به: {}'.format(
                    self.dataAccess.translate(data['table'])))
                self.ui.chosenPath.setCurrentIndex(self.ui.chosenPath.count() - 1)
                self.ui.mainList.setRowCount(len(ids))
                self.ui.mainList.setColumnCount(2)
                self.ui.mainList.setHorizontalHeaderItem(0, QtWidgets.QTableWidgetItem('کد شناسایی'))
                self.ui.mainList.setHorizontalHeaderItem(1, QtWidgets.QTableWidgetItem('شناسه'))
                ind = 0
                for id in ids:
                    self.ui.mainList.setItem(ind, 0, QtWidgets.QTableWidgetItem(str(id['id'])))
                    self.ui.mainList.setItem(ind, 1, QtWidgets.QTableWidgetItem(str(id['smid'])))
                    ind += 1
            else:
                self.msgUser('fail', 'چیزی برای نمایش وجود ندارد')

        # self.ui.mainList.resizeColumnsToContents()
        self.ui.chosenPath.blockSignals(False)
        if self.dataAccess.isTableGeo(self.currTable):
            self.ui.showInMap.setEnabled(True)
        else:
            self.ui.showInMap.setEnabled(False)

    def getNewList(self, row, col):
        self.msgUser('wait')

        self.ui.chosenPath.blockSignals(True)
        newPath = {}

        if self.pathList[-1]['type'] == 'posts':
            newPath['type'] = 'table-count'
            newPath['data'] = { 'table': 'substat', 'idvalue': self.ui.mainList.item(row, 1).text() }

        elif self.pathList[-1]['type'] == 'circuits':
            newPath['type'] = 'table-count'
            newPath['data'] = { 'table': 'circuit', 'idvalue': self.ui.mainList.item(row, 1).text() }

        elif self.pathList[-1]['type'] == 'table-count':
            newPath['type'] = 'other-table'
            newPath['data'] = {
                    'table': self.ui.mainList.item(row, 0).text(),
                    'con_table': self.pathList[-1]['data']['table'],
                    'con_idvalue': self.pathList[-1]['data']['idvalue']
                }

        elif self.pathList[-1]['type'] == 'other-table':
            newPath['type'] = 'table-count'
            newPath['data'] = { 'table': self.pathList[-1]['data']['table'], 'idvalue': self.ui.mainList.item(row, 0).text() }

        if self.checkIfInPathList(newPath['type'], newPath['data']):
            self.msgUser('fail', 'این مسیر از قبل به لیست مسیرهای شما اضافه شده است')
        else:
            self.listNew(newPath['type'], newPath['data'])

        self.ui.chosenPath.blockSignals(False)

        self.msgUser('none')

    def pathChanged(self):

        self.msgUser('wait')

        self.ui.chosenPath.blockSignals(True)

        currInd = self.ui.chosenPath.currentIndex()
        thisPathItem = self.pathList[currInd]
        self.pathList = self.pathList[:currInd]
        while (True):
            if self.ui.chosenPath.count() > len(self.pathList):
                self.ui.chosenPath.removeItem(self.ui.chosenPath.count() - 1)
            else:
                break

        if thisPathItem['type'] == 'posts':
            self.listNew('posts', None)

        elif thisPathItem['type'] == 'circuits':
            self.listNew('circuits', None)

        elif thisPathItem['type'] == 'table-count':
            self.listNew('table-count', thisPathItem['data'])

        elif thisPathItem['type'] == 'other-table':
            self.listNew('other-table', thisPathItem['data'])
    
        self.ui.chosenPath.blockSignals(False)

        self.msgUser('none')

    def emptyMainList(self):
        self.ui.mainList.clear()
        self.ui.mainList.setRowCount(0)
        self.ui.mainList.setColumnCount(0)
        self.ui.search.clear()
        self.ui.search.setEnabled(False)

    def checkIfInPathList(self, type, data):
        for item in self.pathList:
            if item['type'] == type and item['data'] == data:
                return True 
        return False

    def showInMap(self):
        tableName = self.currTable
        smid = ''
        row = self.ui.mainList.currentRow()
        if row == -1:
            return
        if self.ui.mainList.item(row, 3):
            smid = int(self.ui.mainList.item(row, 3).text())
        else:
            smid = int(self.ui.mainList.item(row, 1).text())
        layer = self.findLayer('public', tableName)

        if layer:
            layer.removeSelection()
            layer.select(smid)
            box = layer.boundingBoxOfSelected()
            layer.removeSelection()
            box.grow(1)
            self.canvas = self.iface.mapCanvas()
            self.canvas.setExtent(box)
            self.canvas.refresh()

    def get_layer_source_table_name(self, layer):
        if layer is None:
            return None
        uri_table = None
        uri = layer.dataProvider().dataSourceUri().lower()
        pos_ini = uri.find('table=')
        pos_end_schema = uri.rfind('.')
        pos_fi = uri.find('" ')
        if pos_ini != -1 and pos_fi != -1:
            uri_table = uri[pos_end_schema+2:pos_fi]
        return uri_table

    def setMenuFont(self , object):
        font = QtGui.QFont()
        font.setFamily("B Nazanin")
        font.setPointSize(10)
        font.setBold(False)
        font.setWeight(50)
        object.setFont(font)

    def reportMenu(self):
        menu = QtWidgets.QMenu()
        menu.addAction('اکسل شیت به شیت' , self.sheetBySheet)
        menu.addAction('اکسل تک شیت رنگی' , self.colorFulMonoSheet)
        menu.addAction('اکسل شیت به شیت رنگی' , self.colorFulSheetBySheet)
        self.setMenuFont(menu)
        self.ui.excelReport_TB.setMenu(menu)

    def colorFulMonoSheet(self):
        self.msgUser('wait')
        cursor = self.dataAccess.getCursor()
        cursor_extra = self.dataAccess.getCursorExtras()
        currentRow = self.ui.mainList.currentRow()
        dispach_code = self.ui.mainList.item(currentRow, 1).text()
        selected_item_name = self.createObjectName(currentRow , 'cfms')
        dest_address = self.getDestFolder() + '/'
        result = EO_ColorfulMonoSheet(cursor , cursor_extra , self.currTable , dispach_code , selected_item_name , dest_address)
        self.msgUser('none')
        if result:
            self.msgUser('success', 'فایل اکسل با موفقیت ذخیره گردید')
        else : 
            self.msgUser('fail', 'خطا در ذخیره فایل اکسل')
    
    def sheetBySheet(self):
        self.msgUser('wait')
        cursor = self.dataAccess.getCursor()
        cursor_extra = self.dataAccess.getCursorExtras()
        currentRow = self.ui.mainList.currentRow()
        dispach_code = self.ui.mainList.item(currentRow, 1).text()
        selected_item_name = self.createObjectName(currentRow , 'ss')
        dest_address = self.getDestFolder() + '/'
        result = EO_SheetBySheet(cursor , cursor_extra , self.currTable , dispach_code , selected_item_name , dest_address)
        self.msgUser('none')
        if result:
            self.msgUser('success', 'فایل اکسل با موفقیت ذخیره گردید')
        else : 
            self.msgUser('fail', 'خطا در ذخیره فایل اکسل')
        
    def colorFulSheetBySheet(self):
        self.msgUser('wait')
        cursor = self.dataAccess.getCursor()
        cursor_extra = self.dataAccess.getCursorExtras()
        currentRow = self.ui.mainList.currentRow()
        dispach_code = self.ui.mainList.item(currentRow, 1).text()
        selected_item_name = self.createObjectName(currentRow , 'cfss')
        dest_address = self.getDestFolder() + '/'
        result = EO_ColorfulSheetBySheet(cursor , cursor_extra , self.currTable , dispach_code , selected_item_name , dest_address)
        self.msgUser('none')
        if result:
            self.msgUser('success', 'فایل اکسل با موفقیت ذخیره گردید')
        else : 
            self.msgUser('fail', 'خطا در ذخیره فایل اکسل')

    def checkBtnCanEnable(self):
        if self.ui.mainList.currentRow() or self.ui.mainList.currentRow() == 0:
            self.ui.excelReport_TB.setEnabled(True)
            self.ui.showInMap.setEnabled(True)
        else:
            self.ui.excelReport_TB.setEnabled(False)
            self.ui.showInMap.setEnabled(False)

    def createObjectName(self , currentRow , type):
        output_format = '.xlsx'
        if type == 'ss':
            output_format = '.xls'
        return type + '-' +self.ui.mainList.item(currentRow, 0).text() + '-' + self.ui.mainList.item(currentRow, 1).text() + output_format

    def getSaveFileDetails(self):
        filePath = QFileDialog.getSaveFileName(self, 'Save File', '', 'Excel (*.xlsx)')[0]
        return filePath

    def getDestFolder(self):
        filePath = QFileDialog.getExistingDirectory(self, 'Choose Folder')
        return filePath

    def excelMenu(self):
        menu = QtWidgets.QMenu()
        menu.addAction('پست ها' , self.exportPosts)
        menu.addAction('مدار ها' , self.exportCircuits)
        self.setMenuFont(menu)
        self.ui.excelExport.setMenu(menu)

    def exportPosts(self):
        filePath = self.getSaveFileDetails()
        self.msgUser('wait')
        process = subprocess.run(
            'python {}/main.py --post --out {}'.format(getAppDir() + '/excel_out', filePath),
            shell=True, capture_output=True, universal_newlines=True, stdin=subprocess.DEVNULL)
        print(process.stderr)
        if process.returncode == 0:
            self.msgUser('success', 'فایل اکسل با موفقیت ذخیره گردید')
        else:
            self.msgUser('fail', 'خطا در ذخیره فایل اکسل')
    
    def exportCircuits(self):
        filePath = self.getSaveFileDetails()
        self.msgUser('wait')
        process = subprocess.run(
            'python {}/main.py --circuit --out {}'.format(getAppDir() + '/excel_out', filePath),
            shell=True, capture_output=True, universal_newlines=True, stdin=subprocess.DEVNULL)
        if process.returncode == 0:
            self.msgUser('success', 'فایل اکسل با موفقیت ذخیره گردید')
        else:
            self.msgUser('fail', 'خطا در ذخیره فایل اکسل')

    def searchNew(self):
        for row in range(self.ui.mainList.rowCount()):
            column = 0
            if self.ui.search.text() in self.ui.mainList.item(row, column).text():
                self.ui.mainList.showRow(row)
            else:
                self.ui.mainList.hideRow(row)

    def eventFilter(self, source, event):
        if (event.type() == QtCore.QEvent.MouseButtonPress and event.buttons() == QtCore.Qt.RightButton):
            self.circuteMenu = QtWidgets.QMenu(self)
            if source is self.ui.mainList.viewport() and self.currTable == 'circuit':
                item = self.ui.mainList.itemAt(event.pos())
                if item is not None:
                    self.towerMenu = QtWidgets.QMenu('انتخاب دکل ها',self)
                    self.setStyleForMenu([self.circuteMenu , self.towerMenu])
                    self.circuteMenu.addMenu(self.towerMenu)
                    self.towerMenu.addAction('مکانی' , self.LocativTower)
                    self.towerMenu.addAction('توصیفی' , self.Descriptivetower)
            else:
                self.circuteMenu.clear()
        return super(Feat_GUI, self).eventFilter(source, event)

    def setStyleForMenu(self , menuList):
        for eachList in menuList:
            eachList.setStyleSheet("QMenu {font-family: B Nazanin; font-size: 15px;}")

    def LocativTower(self):
        self.initBufferDialogGUI()
        
    def locativTowerSelection(self):
        current_row = self.ui.mainList.currentRow()
        item_smid = self.ui.mainList.item(current_row, 1).text()
        locative_tower = self.dataAccess.selectLocativTower(self.bufferSize , item_smid)
        self.selectTowerInGIS(locative_tower)

    def Descriptivetower(self):
        current_row = self.ui.mainList.currentRow()
        item_smid = self.ui.mainList.item(current_row, 1).text()
        descriptive_tower = self.dataAccess.selectDescriptivetower(item_smid)
        self.selectTowerInGIS(descriptive_tower)
        
    def selectTowerInGIS(self , towerListIds):
        layer = self.findLayer('public' , 'tower')
        if layer and towerListIds:
            layer.select(towerListIds)
            self.msgUser('success' , 'عوارض با موفقیت انتخاب شدند')
        else:
            self.msgUser('fail', 'چیزی برای نمایش وجود ندارد')

    def initBufferDialogGUI(self):
        self.winWorkflow = QtWidgets.QDialog()
        self.bd = BufferDialog()
        self.bd.setupUi(self.winWorkflow)
        self.winWorkflow.show()
        self.bd.sendBuffer.clicked.connect(self.getBufferSize)
        
    def findLayer(self,schema_name,layer_name):
        layers = QgsProject.instance().mapLayers()
        for layer_id, layer in layers.items():
            if '"'+schema_name+'"."'+layer_name+'"' in layer.source():
                return layer

    def getBufferSize(self):
        bufferSizeValue = self.bd.bufferSize.value()
        if bufferSizeValue == 0:
            self.msgUser('fail','لطفا مقدار صحیح وارد کنید.')
            self.getBufferSize()
        else:
            self.bufferSize = bufferSizeValue
            self.winWorkflow.close()
            self.locativTowerSelection()