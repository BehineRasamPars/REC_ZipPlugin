import sys, os
import re
from mylib import getAppDir
os.path.join(f"{getAppDir()}","\package")
import datetime, time
import pandas as pd
import psycopg2, psycopg2.extras
from psycopg2 import sql
from mylib import *
import configparser
from os.path import expanduser
from openpyxl import load_workbook
import re
import argparse
import numpy as np



class ExcelOut:

    conf = {}
    out = None


    def __init__(self):
        self.setConf()


    # Get a connection to the database.
    def getConnElect(self):
        try:
            conn = psycopg2.connect(user = self.conf['DB_user'],
                            password = self.conf['DB_pass'],
                            host = self.conf['DB_host'],
                            port = self.conf['DB_port'],
                            dbname = 'electricity_red')
            conn.autocommit = True
            return conn
        except Exception as e:
            print(e)
            return False


    # Set self.conf.
    def setConf(self):

        self.conf['mainPath'] = getAppDir()
        self.conf['confFilePath'] = self.conf['mainPath'] + '\\..\\main.conf'

        confFile = configparser.ConfigParser()
        confFile.read(self.conf['confFilePath'])
        self.conf['fileLogging'] = confFile.getboolean('Main', 'file_logging')
        self.conf['DB_host'] = confFile['DB']['host']
        self.conf['DB_port'] = confFile['DB']['port']
        self.conf['DB_user'] = confFile['DB']['user']
        self.conf['DB_pass'] = confFile['DB']['pass']


    def getPostList(self):
        try:
            cur = self.getConnElect().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                SELECT
                    subst_code, subf_name, estab_type, own_type, conv_ratio, utili_date,
                    t_re.rea_count, t_re.rea_cap,
                    t_ca.cap_count, t_ca.cap_cap
                FROM
                    substat
                LEFT JOIN (
                    SELECT
                        substat.subst_code,
                        count(reactor.reac_cap) AS rea_count, COALESCE(sum(reactor.reac_cap), 0) AS rea_cap
                    FROM
                        substat
                    LEFT JOIN
                        reactor ON (substat.subst_code = reactor.subst_code)
                    GROUP BY
                        substat.subst_code) t_re USING (subst_code)
                LEFT JOIN (
                    SELECT
                        substat.subst_code,
                        count(shca_bnk.nomi_cap) AS cap_count, COALESCE(sum(shca_bnk.nomi_cap), 0) AS cap_cap
                    FROM
                        substat
                    LEFT JOIN
                        shca_bnk ON (substat.subst_code = shca_bnk.subst_code)
                    GROUP BY
                        substat.subst_code) t_ca USING (subst_code)
                """)
            rows = cur.fetchall()
            return rows
        except Exception as e:
            return False


    def getCircuitList(self):
        try:
            cur = self.getConnElect().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                    SELECT
                        circuit.smid, circuit.cir_name, circt_id, circt_len 
                    FROM circuit
                    ORDER BY circuit.circt_id
                """)
            rows = cur.fetchall()
            return rows
        except Exception as e:
            return False


    def getCircuitNamesSE(self, cirSMID):
        try:
            cur = self.getConnElect().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                SELECT
                    circuit.smid, com_link.or_name AS start, com_link.dest_name AS end
                FROM circuit
                LEFT JOIN tr_line USING (trlin_id)
                LEFT JOIN com_link USING (trlin_id)
                WHERE circuit.smid = %s
                LIMIT 1
                """, (cirSMID,))
            rows = cur.fetchone()
            return rows
        except Exception as e:
            return False


    def getCircuitCowName(self, cirSMID):
        try:
            cur = self.getConnElect().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                SELECT
                    circuit.smid, conwir_type.cow_name
                FROM circuit
                LEFT JOIN cir_sec USING (circt_id)
                LEFT JOIN cir_seg ON (cir_seg.cisec_id = cir_sec.cirsec_id)
                LEFT JOIN ovci_seg USING (ciseg_id)
                LEFT JOIN conwir_type USING (cowtype_id)
                WHERE circuit.smid = %s
                LIMIT 1
                """, (cirSMID,))
            rows = cur.fetchone()
            return rows
        except Exception as e:
            return False


    def getCircuitDates(self, cirSMID):
        try:
            cur = self.getConnElect().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                    SELECT
                        circuit.smid, circuit.cir_name, ovpat_seg.utili_date, ovpat_seg.dev_date
                    FROM circuit
                    LEFT JOIN cir_sec USING (circt_id)
                    LEFT JOIN cir_seg ON (cir_seg.cisec_id = cir_sec.cirsec_id)
                    LEFT JOIN ovpat_seg USING (ovpasg_id)
                    WHERE circuit.smid = %s
                    LIMIT 1
                """, (cirSMID,))
            rows = cur.fetchone()
            return rows
        except Exception as e:
            return False


    def getCircuitTowerType(self, cirSMID):
        try:
            cur = self.getConnElect().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                SELECT
                    circuit.smid, com_towr.tower_type
                FROM circuit
                LEFT JOIN cir_sec USING (circt_id)
                LEFT JOIN cir_seg ON (cir_seg.cisec_id = cir_sec.cirsec_id)
                LEFT JOIN ovpat_seg USING (ovpasg_id)
                LEFT JOIN tower_ovpat_seg USING (ovpasg_id)
                LEFT JOIN com_towr USING (tower_id)
                WHERE circuit.smid = %s
                LIMIT 1
                """, (cirSMID,))
            rows = cur.fetchone()
            return rows
        except Exception as e:
            return False


    def getCircuitLength_way(self):
        try:
            cur = self.getConnElect().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                    SELECT smid, sum(sum) AS len
                    FROM
                    (
                        SELECT
                            circuit.smid, COALESCE(sum(ovpat_seg.path_length), 0) AS sum
                        FROM circuit
                        LEFT JOIN cir_sec USING (circt_id)
                        LEFT JOIN cir_seg ON (cir_seg.cisec_id = cir_sec.cirsec_id)
                        LEFT JOIN ovpat_seg USING (ovpasg_id)
                        GROUP BY circuit.smid
                        UNION
                        SELECT
                            circuit.smid, COALESCE(sum(unpat_seg.path_length), 0) AS sum
                        FROM circuit
                        LEFT JOIN cir_sec USING (circt_id)
                        LEFT JOIN cir_seg ON (cir_seg.cisec_id = cir_sec.cirsec_id)
                        LEFT JOIN unpat_seg ON (unpat_seg.unpasg_id = cir_seg.ovpasg_id)
                        GROUP BY circuit.smid
                    ) AS t1
                    GROUP BY smid
                """)
            rows = cur.fetchall()
            return rows
        except Exception as e:
            return False   


    def getCircuitTowerCounts(self):
        try:
            cur = self.getConnElect().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                SELECT
                    circuit.smid,
                    COALESCE(sum(ovpat_seg.sustow_num), 0) AS sus,
                    COALESCE(sum(ovpat_seg.deetow_num), 0) AS dee,
                    COALESCE(sum(ovpat_seg.tentow_num), 0) AS ten
                FROM circuit
                LEFT JOIN cir_sec USING (circt_id)
                LEFT JOIN cir_seg ON (cir_seg.cisec_id = cir_sec.cirsec_id)
                LEFT JOIN ovpat_seg USING (ovpasg_id)
                GROUP BY circuit.smid
                """)
            rows = cur.fetchall()
            return rows
        except Exception as e:
            return False


    def getCircuitInsulatCounts(self):
        try:
            cur = self.getConnElect().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                SELECT smid, COALESCE(max(count), 0) AS count FROM (
                    SELECT
                        circuit.smid, insulat.insul_num AS count
                    FROM circuit
                    LEFT JOIN cir_sec USING (circt_id)
                    LEFT JOIN cir_seg ON (cir_seg.cisec_id = cir_sec.cirsec_id)
                    LEFT JOIN insu_str USING (ciseg_id)
                    LEFT JOIN insulat USING (insustr_id)
                    --LEFT JOIN ins_type USING (isutyp_id)
                ) AS t1
                GROUP BY smid
                """)
            rows = cur.fetchall()
            return rows
        except Exception as e:
            return False


    def getCircuitBundle_Num(self):
        try:
            cur = self.getConnElect().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                SELECT smid, COALESCE(max(bundle_num), 0) AS num FROM (
                    SELECT
                        circuit.smid, ovci_seg.bundle_num
                    FROM circuit
                    LEFT JOIN cir_sec USING (circt_id)
                    LEFT JOIN cir_seg ON (cir_seg.cisec_id = cir_sec.cirsec_id)
                    LEFT JOIN ovci_seg USING (ciseg_id)
                    LEFT JOIN conwir_type USING (cowtype_id)
                ) t1
                GROUP BY smid
                """)
            rows = cur.fetchall()
            return rows
        except Exception as e:
            return False


    def getTransCap(self, substCode):
        try:
            cur = self.getConnElect().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                    SELECT
                        subst_code, pow_tran.smid, count(pow_tran.smid), COALESCE(max(nomi_cap.term_numcap), 0) AS cap
                    FROM
                        substat
                    LEFT JOIN pow_tran USING (subst_code)
                    LEFT JOIN tank ON (pow_tran.ptran_id = tank.tra_rac_id)
                    LEFT JOIN winding USING (tank_id)
                    LEFT JOIN nomi_cap USING (wind_id)
                    WHERE subst_code = %s
                    GROUP BY pow_tran.smid, subst_code
                    ORDER BY subst_code 
                    ;
                """, (substCode,))
            rows = cur.fetchall()
            return rows
        except Exception as e:
            return False


    def outPost(self):
        posts = self.getPostList()
        dataList = {
            'row': [],
            'subf_name': [],
            'estab_type': [],
            'own_type': [],
            'conv_ratio': [],
            'trans_c': [],
            'trans_m': [],
            'trans_y': [],
            're_c': [],
            're_m': [],
            'cap_c': [],
            'cap_m': [],
            'trans_total': [],
            'max_a_mvar': [],
            'max_a_mwat': [],
            'ratio': [],
            'utili_year': []
        }
        count = 0
        for post in posts:
            count += 1
            transCaps = self.getTransCap(post['subst_code'])
            trans_total = 0
            for trans in transCaps:
                if post['utili_date']:
                    parts = re.findall('\/(\d+)$', post['utili_date'])
                    if parts:
                        year = parts[0]
                    else:
                        year = 0
                else:
                    year = 0
                dataList['utili_year'].append(year)
                trans_total +=  trans['count'] * trans['cap']
                dataList['row'].append(count)
                dataList['subf_name'].append(post['subf_name'])
                dataList['estab_type'].append(post['estab_type'])
                dataList['own_type'].append(post['own_type'])
                dataList['conv_ratio'].append(post['conv_ratio'])
                dataList['trans_c'].append(trans['count'])
                dataList['trans_m'].append(trans['cap'])
                dataList['trans_y'].append(0)
                dataList['re_c'].append(post['rea_count'])
                dataList['re_m'].append(post['rea_cap'])
                dataList['cap_c'].append(post['cap_count'])
                dataList['cap_m'].append(post['cap_cap'])
                dataList['max_a_mvar'].append(0)
                dataList['max_a_mwat'].append(0)
                dataList['ratio'].append(0)
                trans_total +=  trans['count'] * trans['cap']
            dataList['trans_total'].append(trans_total)

        filename = getAppDir() + '\\post_template.xlsx'

        max_len = max(len(dataList['utili_year']), len(dataList['row']),len(dataList['subf_name']),len(dataList['estab_type']),len(dataList['estab_type']),len(dataList['own_type']),len(dataList['conv_ratio']),len(dataList['trans_c']),len(dataList['trans_m']),len(dataList['trans_y']),len(dataList['re_c']),len(dataList['re_m']),len(dataList['cap_c']),len(dataList['cap_m']),len(dataList['max_a_mvar']), len(dataList['max_a_mwat']),len(dataList['ratio']), len(dataList['trans_total']))
        dataList['row'] = dataList['row'] + [None] * (max_len - len(dataList['row']))
        dataList['utili_year'] = dataList['utili_year'] + [None] * (max_len - len(dataList['utili_year']))
        dataList['subf_name'] = dataList['subf_name'] + [None] * (max_len - len(dataList['subf_name']))
        dataList['estab_type'] = dataList['estab_type']  + [None] * (max_len - len(dataList['estab_type'] ))
        dataList['own_type']= dataList['own_type'] + [None] * (max_len - len(dataList['own_type']))
        dataList['conv_ratio'] = dataList['conv_ratio'] + [None] * (max_len - len(dataList['conv_ratio']))
        dataList['trans_c'] = dataList['trans_c'] + [None] * (max_len - len(dataList['trans_c']))
        dataList['trans_m'] = dataList['trans_m'] + [None] * (max_len - len(dataList['trans_m']))
        dataList['trans_y'] = dataList['trans_y'] + [None] * (max_len - len(dataList['trans_y']))
        dataList['re_c'] = dataList['re_c'] + [None] * (max_len - len(dataList['re_c']))
        dataList['re_m'] = dataList['re_m'] + [None] * (max_len - len(dataList['re_m']))
        dataList['cap_c'] = dataList['cap_c'] + [None] * (max_len - len(dataList['cap_c']))
        dataList['cap_m'] = dataList['cap_m'] + [None] * (max_len - len(dataList['cap_m']))
        dataList['max_a_mvar'] = dataList['max_a_mvar'] + [None] * (max_len - len(dataList['max_a_mvar']))
        dataList['max_a_mwat'] = dataList['max_a_mwat'] + [None] * (max_len - len(dataList['max_a_mwat']))
        dataList['ratio'] = dataList['ratio'] + [None] * (max_len - len(dataList['ratio']))
        dataList['trans_total'] = dataList['trans_total'] + [None] * (max_len - len(dataList['trans_total']))

        df = pd.DataFrame(dataList)
        df = df.set_index([
            'row', 'subf_name', 'estab_type', 'own_type', 'conv_ratio', 'trans_c', 'trans_m', 'trans_y',
            're_c', 're_m', 'cap_c', 'cap_m', 'trans_total', 'max_a_mvar', 'max_a_mwat', 'ratio', 'utili_year'
        ])
        df.to_excel(self.out)

        book = load_workbook(filename)
        writer = pd.ExcelWriter(self.out, engine='openpyxl')
        writer.book = book
        writer.sheets = {ws.title: ws for ws in book.worksheets}
        sheetname = 'Sheet1'
        df.to_excel(writer,sheet_name=sheetname, startrow=writer.sheets[sheetname].max_row - 1,
            header = False)
        writer.save()


    def outCircuit(self):

        dataList = {
            'row': [],
            'name': [],
            'name_start': [],
            'name_end': [],
            'code': [],
            'length_cir': [],
            'length_way': [],
            'count_hadi': [],
            'energy_out': [],
            'ratio': [],
            'tower_type': [],
            'tower_count1': [],
            'tower_count2': [],
            'tower_count3': [],
            'year_usage': [],
            'year_finish': [],
            'amp_1': [],
            'amp_2': [],
            'amp_3': [],
            'amp_4': [],
            'amp_5': [],
            'amp_6': [],
            'name_hadi': [],
            'wirguar_1': [],
            'wirguar_2': [],
            'wirguar_3': [],
            'wirguar_4': [],
            'isolator_type': [],
            'isolator_count': [],
            'str_insu_count1': [],
            'str_insu_count2': [],
            'str_insu_count3': [],
            'schema': []
        }

        lengths = {}
        lengths1 = self.getCircuitLength_way()
        for len in lengths1:
            lengths[len['smid']] = len['len']

        towerCounts = {}
        towerCounts1 = self.getCircuitTowerCounts()
        for count in towerCounts1:
            towerCounts[count['smid']] = { 'sus': count['sus'], 'dee': count['dee'], 'ten': count['ten'] }

        insCounts1 = self.getCircuitInsulatCounts()
        insCounts = {}
        for insCount in insCounts1:
            insCounts[insCount['smid']] = insCount['count']

        bundleNums1 = self.getCircuitBundle_Num()
        bundleNums = {}
        for bundleNum in bundleNums1:
            bundleNums[bundleNum['smid']] = bundleNum['num']

        circuits = self.getCircuitList()
        count = 0
        for circuit in circuits:
            namesSE = self.getCircuitNamesSE(circuit['smid'])
            cowName = str(self.getCircuitCowName(circuit['smid'])['cow_name'] or '')
            dates = self.getCircuitDates(circuit['smid'])
            towerType = str(self.getCircuitTowerType(circuit['smid'])['tower_type'] or '')
            count += 1
            dataList['row'].append(count)
            dataList['name'].append(circuit['cir_name'])
            dataList['name_start'].append(namesSE['start'] or '')
            dataList['name_end'].append(namesSE['end'] or '')
            dataList['code'].append(circuit['circt_id'])
            dataList['length_cir'].append(circuit['circt_len'])
            dataList['length_way'].append(lengths[circuit['smid']])
            dataList['count_hadi'].append(bundleNums[circuit['smid']])
            dataList['energy_out'].append('-')
            dataList['ratio'].append('-')
            dataList['tower_type'].append(towerType)
            dataList['tower_count1'].append(towerCounts[circuit['smid']]['sus'])
            dataList['tower_count2'].append(towerCounts[circuit['smid']]['dee'])
            dataList['tower_count3'].append(towerCounts[circuit['smid']]['ten'])
            if dates['utili_date']:
                parts = re.findall('\/(\d+)$', dates['utili_date'])
                year = parts[0]
            else:
                year = '-'
            dataList['year_usage'].append(year)
            if dates['dev_date']:
                parts = re.findall('\/(\d+)$', dates['dev_date'])
                year = parts[0]
            else:
                year = '-'
            dataList['year_finish'].append(year)
            dataList['amp_1'].append('-')
            dataList['amp_2'].append('-')
            dataList['amp_3'].append('-')
            dataList['amp_4'].append('-')
            dataList['amp_5'].append('-')
            dataList['amp_6'].append('-')
            dataList['name_hadi'].append(cowName)
            dataList['wirguar_1'].append('-')
            dataList['wirguar_2'].append('-')
            dataList['wirguar_3'].append('-')
            dataList['wirguar_4'].append('-')
            dataList['isolator_type'].append('-')
            dataList['isolator_count'].append(insCounts[circuit['smid']])
            dataList['str_insu_count1'].append('-')
            dataList['str_insu_count2'].append('-')
            dataList['str_insu_count3'].append('-')
            dataList['schema'].append('-')

        filename = getAppDir() + '\\circuit_template.xlsx'
        df = pd.DataFrame(dataList)
        df = df.set_index([
            'row', 'name', 'name_start', 'name_end', 'code', 'length_cir', 'length_way', 'count_hadi',
            'energy_out', 'ratio', 'tower_type', 'tower_count1', 'tower_count2', 'tower_count3',
            'year_usage', 'year_finish',
            'amp_1', 'amp_2', 'amp_3', 'amp_4', 'amp_5', 'amp_6', 'name_hadi',
            'wirguar_1', 'wirguar_2', 'wirguar_3', 'wirguar_4',
            'isolator_type', 'isolator_count', 'str_insu_count1', 'str_insu_count2', 'str_insu_count3',
            'schema'
        ])
        df.to_excel(self.out)
        book = load_workbook(filename)
        writer = pd.ExcelWriter(self.out, engine='openpyxl')
        writer.book = book
        writer.sheets = {ws.title: ws for ws in book.worksheets}
        sheetname = 'Sheet1'
        df.to_excel(writer,sheet_name=sheetname, startrow=writer.sheets[sheetname].max_row - 1,
            header = False)
        writer.save()


def main():

    parser = argparse.ArgumentParser()
    parser.add_argument("--post", action='store_true')
    parser.add_argument("--circuit", action='store_true')
    parser.add_argument("--out", type = str, nargs='?')
    args = parser.parse_args()
    if not args.post and not args.circuit:
        parser.error('At least one of --circuit or --post is required.')

    app = ExcelOut()
    app.out = args.out

    if args.post:
        app.outPost()
    elif args.circuit:
        app.outCircuit()    


if __name__ == '__main__':
    main()