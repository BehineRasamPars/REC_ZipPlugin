import sys, os, os.path
import datetime, time
import logging
import configparser
import psycopg2, psycopg2.extras
from psycopg2 import sql
from .mylib import *
from .rassam import *
#========================================================

class DataAccess:

    def __init__(self , db_conn):
        self.db_conn = db_conn

    # Get a connection to the database.

    def getConnElect(self):
        try:
            return self.db_conn
        except Exception as e:
            print(e)
            return False

    def calculateDistance(self, circuit_code):
        try:
            cursor = self.getConnElect().cursor()
            query = "with tt as (select st_linemerge(st_union(smgeometry)) as geom from cir_seg where cisec_id in (select cirsec_id from cir_sec where circt_id = '{}')) select substat.subf_name from tt inner join substat on st_intersects(substat.smgeometry, st_startpoint(tt.geom))".format(circuit_code)
            cursor.execute(query)
            result = cursor.fetchone()
            return result
        except Exception as e:
            print(e)
            return None

    def calculateVectorPlace(self, geom_part, circuit_code):
        try :
            cursor = self.getConnElect().cursor()
            query =  "with rr as (with tt as (select st_linemerge(st_union(smgeometry)) as geom from cir_seg where cisec_id in (select cirsec_id from cir_sec where circt_id = '{}')) select ST_LineInterpolatePoint(geom,({})/st_length(geom)) as geo from tt) select st_x(geo), st_y(geo) from rr".format(circuit_code, geom_part)
            cursor.execute(query)
            result = cursor.fetchone()
            return result
        except Exception as e:
            self.getConnElect().rollback()
            print(e)
            return None

    def getCircuitList(self):
        try:
            cursor = self.getConnElect().cursor()
            query =  """select cir_name , circt_id , circt_len from circuit"""
            cursor.execute(query)
            result = cursor.fetchall()
            return result
        except Exception as e:
            print(e)
            return None

    def getCircuitPosts(self, circuit_code):
        try:
            cursor = self.getConnElect().cursor()
            query =  """SELECT public.fir_end_circuit('{}')""".format(circuit_code)
            cursor.execute(query)
            result = cursor.fetchone()
            return result
        except Exception as e:
            print(e)
            return None

    def tablesFieldsName(self, table_name):
        try:
            cursor = self.getConnElect().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            query = """select smi.smfieldname ,smi.smfieldcaption from public.smregister sr inner join public.smfieldinfo smi on sr.smdatasetid = smi.smdatasetid where sr.smdatasetname  = '{}'""".format(table_name)
            cursor.execute(query)
            fields_name = cursor.fetchall()
            result_dict = {row['smfieldname']: row['smfieldcaption'] for row in fields_name}
            return result_dict
        except Exception as e:
            print(e)
            return None

    def getTowersPoint(self, x, y):
        try:
            cursor = self.getConnElect().cursor()
            query = """select public.dist_rel_towers({},{})""".format(x,y)
            cursor.execute(query)
            tower_ids = cursor.fetchall()
            tower_ids = [row[0] for row in tower_ids]
            tower_ids = list(filter(None, tower_ids[0]))
            return tower_ids
        except Exception as e:
            print(e)
            return None

    def getTowersDetails(self, tower_ids):
        try:
            cursor = self.getConnElect().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            query = """select * from public.tower where tower_id in ('{}')""".format("', '".join(tower_ids))
            cursor.execute(query)
            tower_dtls = cursor.fetchall()
            return tower_dtls
        except Exception as e:
            print(e)
            return None