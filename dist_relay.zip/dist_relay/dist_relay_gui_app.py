from .dist_relay_dialog import DistRelay
from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication, Qt
from qgis.PyQt.QtGui import QIcon, QStandardItem
from qgis.PyQt.QtWidgets import QAction, QMessageBox, QTableWidgetItem, QInputDialog
from PyQt5.QtWidgets import QMenu
import os.path
import pyplugin_installer
from qgis import utils, gui, core
from qgis.gui import QgsVertexMarker , QgsMapCanvas
from .rassam import *
from qgis.gui import QgsMapLayerComboBox
from qgis.utils import iface
from qgis.gui import QgsMapToolIdentify
from qgis.core import QgsProject
from .dist_relay_dialog import DistRelay
from PyQt5.QtCore import QCoreApplication, QEvent, QObject


class DistRelay_GUI(QtWidgets.QMainWindow):
    def __init__(self , usePlugin):
        super().__init__()
        self.usePlugin = usePlugin
        self.plugin_dir = os.path.dirname(__file__)
        self.conn = self.usePlugin.dBConnection
        self.get_layer()
        self.initUI()

    def initUI(self):
        self.dlg = DistRelay()
        self.trigger_check()
        self.run()
        self.set_tool_button_action()

    def initial_prep(self):
        self.initial_msgBox()
        self.fillCircuitsCmb()
        self.calculateCircuitLength()
        return True
        
    def run(self):
        prep = self.initial_prep()
        if prep is not False:
            self.selectCircuit()
            self.dlg.show()
            result = self.dlg.exec_()
            if result:
                pass


    def help_menu(self):
        x = self.dlg.HelpBtn
        x.setIcon(QIcon(os.path.dirname(__file__) + '/help.png'))
        menu = QMenu()
        i = menu.addAction("PDF", self.action1)
        i.setIcon(QIcon(os.path.dirname(__file__) + '/pdfhelp.png'))
        z = menu.addAction("ویدیو", self.action2)
        z.setIcon(QIcon(os.path.dirname(__file__) + '/vidhelp.png'))
        self.dlg.HelpBtn.setMenu(menu)

    def action1(self):
        self.help_btn()

    def action2(self):
        save_path = os.path.dirname(__file__) + '/user_help'
        file_name = "help_vid.mp4"
        completeName = os.path.join(save_path, file_name)
        os.startfile(completeName)

    def help_btn(self):
        save_path = os.path.dirname(__file__) + '/user_help'
        file_name = "help_pdf.pdf"
        completeName = os.path.join(save_path, file_name)
        os.startfile(completeName)

    def get_layer(self):
        self.layer = QgsProject.instance().mapLayersByName('تکه مدار')[0]

    def trigger_check(self):
        self.layer.selectionChanged.connect(self.onSelectionChanged)
        self.dlg.circuitchoice_CMB.currentIndexChanged.connect(
            self.calculateCircuitLength)


    def onSelectionChanged(self , *args):
        self.selectCircuit()

    def get_marker_options(self):
        marker_color = self.dlg.colorBox.currentText()
        marker_size = self.dlg.sizeBox.currentText()
        marker_width = self.dlg.widthBox.currentText()
        marker_shape = self.dlg.shapeBox.currentText()
        return marker_color, marker_size, marker_width, marker_shape

    def calculate_distance_with_delete(self):
        DistRelay.clearMarkersList(self.dlg.markers)
        self.calculate_distance()

    def calculate_distance(self):
        length = self.dlg.doubleSpinBox.value()
        if length > float(self.dlg.circuitLentgh_LE.text()):
            self.iface.messageBar().pushMessage("Warning", "طول وارد شده از طول مدار بیشتر است",
                                                level=utils.Qgis.Warning, duration=10)
            return
        circuit_name = self.dlg.circuitchoice_CMB.currentText()
        circuit_code = circuit_name.split('کد:')[1].strip()
        cursor = self.conn.getConn().cursor()

        query = "with tt as (select st_linemerge(st_union(smgeometry)) as geom from cir_seg where cisec_id in (select cirsec_id from cir_sec where circt_id = '" + circuit_code + "')) select substat.subf_name from tt inner join substat on st_intersects(substat.smgeometry, st_startpoint(tt.geom))"
        cursor.execute(query)
        first_side = cursor.fetchone()[0]
        if self.dlg.source_RBTN.isChecked():
            first_side_sel = self.dlg.beginPost_LE.text()
        elif self.dlg.dest_RBTN.isChecked():
            first_side_sel = self.dlg.endPost_LE.text()
        else:
            self.iface.messageBar().pushMessage("Warning", "لطفا ابتدای مدار را مشخص نمایید", level=utils.Qgis.Warning,
                                                duration=10)
            return

        if first_side == first_side_sel:
            geom_part = str(length)
        else:
            geom_part = "st_length(geom) -" + str(length)

        query = "with rr as (with tt as (select st_linemerge(st_union(smgeometry)) as geom from cir_seg where cisec_id in (select cirsec_id from cir_sec where circt_id = '" + \
                circuit_code + "')) select ST_LineInterpolatePoint(geom,(" + geom_part + ")/st_length(geom)) as geo from tt) select st_x(geo), st_y(geo) from rr"

        cursor.execute(query)
        a_c = cursor.fetchone()
        coord_x = a_c[0]
        coord_y = a_c[1]
        self.dlg.x_geom_LE.setText('{0:.2f}'.format(coord_x))
        self.dlg.y_geom_LE.setText('{0:.2f}'.format(coord_y))
        canvas = self.iface.mapCanvas()
        rec_shape = self.get_marker_options()
        shape_ops = self.set_marker(rec_shape[0], rec_shape[1], rec_shape[2], rec_shape[3])
        m = QgsVertexMarker(canvas)
        m.setCenter(core.QgsPointXY(coord_x, coord_y))
        m.setColor(qgis.PyQt.QtGui.QColor(shape_ops[0]))
        m.setIconSize(int(shape_ops[1]))
        m.setPenWidth(int(shape_ops[2]))
        if shape_ops[3] == 'دایره':
            m.setIconType(QgsVertexMarker.ICON_CIRCLE)
        elif shape_ops[3] == 'ضربدر':
            m.setIconType(QgsVertexMarker.ICON_CROSS)
        elif shape_ops[3] == 'مثلث':
            m.setIconType(QgsVertexMarker.ICON_INVERTED_TRIANGLE)
        else:
            m.setIconType(QgsVertexMarker.ICON_RHOMBUS)
        self.dlg.markers.append(m)
        if self.dlg.zoomChk.isChecked():
            offset = 10
            zoomRectangle = core.QgsRectangle(coord_x - offset, coord_y - offset, coord_x + offset, coord_y + offset)
            canvas.setExtent(zoomRectangle)
        canvas.refresh()

    def initial_msgBox(self):
        self.msgBox = QtWidgets.QMessageBox()
        self.msgBox.addButton(QtWidgets.QPushButton("باشد"),
                             QtWidgets.QMessageBox.YesRole)

    def msgUser(self, type, msg=None):  # Send a message to the user.
        if type == 'success':
            self.msgBox.setIcon(QtWidgets.QMessageBox.Information)
            if not msg:
                msg = "عملیات با موفقیت انجام شد."
            self.msgBox.setText(msg)
            self.msgBox.setWindowTitle("موفقیت")
        elif type == 'fail':
            self.msgBox.setIcon(QtWidgets.QMessageBox.Critical)
            if not msg:
                msg = "عملیات با شکست مواجه شد."
            self.msgBox.setText(msg)
            self.msgBox.setWindowTitle("شکست")
        result = self.msgBox.exec_()

    def fillCircuitsCmb(self):
        try:
            cursor = self.conn.getConn().cursor()
            cursor.execute("select cir_name || ' کد: ' || circt_id from circuit")
            k = 0
            for a_circt in cursor.fetchall():
                self.dlg.circuitchoice_CMB.insertItem(k, a_circt[0])
                k += 1
        except Exception as e:
            print(f'in error{e}')

    def selectCircuit(self):
        try:
            num_selected_features = self.layer.selectedFeatureCount()
            if num_selected_features == 1:
                selected_feature = self.layer.selectedFeatures()[0]
                attribute = selected_feature.attribute('ciseg_id')
                cursor = self.conn.getConn().cursor()
                cursor.execute("select circuit.cir_name || ' کد: ' || circuit.circt_id from circuit inner join cir_sec on circuit.circt_id = cir_sec.circt_id inner join cir_seg on cir_sec.cirsec_id = cir_seg.cisec_id where cir_seg.ciseg_id = '" + attribute + "'")
                result = cursor.fetchone()
                self.dlg.circuitchoice_CMB.setCurrentText(result[0])
            elif num_selected_features > 1 :
                self.msgUser('fail' , 'لطفا تنها یک تکه مدار را انتخاب کنید')
                return
            else:
                self.msgUser('fail' , 'لطفا حداقل یک تکه مدار را انتخاب کنید')
                return
        except Exception as e:
            print(f'inyeki error{e}')

    def checkErrors(self):
        self.indexErrorMessage()

    def checkStartEndPoint(self , subs):
        if len(subs) == 2:
            return subs[0] , subs[1]
        elif len(subs) == 1:
            return subs[0] , 'یافت نشد'
        return 'یافت نشد' , 'یافت نشد'


    def calculateCircuitLength(self):
        try:
            circuit_name = self.dlg.circuitchoice_CMB.currentText()
            circuit_code = circuit_name.split('کد:')[1].strip()
            cursor = self.conn.getConn().cursor()
            cursor.execute(
                "select round(sum(st_length(smgeometry))::numeric,2) from cir_seg where cisec_id in (select cirsec_id from cir_sec where circt_id = '" + circuit_code + "')")
            circt_length = str(cursor.fetchall()[0][0])
            self.dlg.circuitLentgh_LE.setText(circt_length)

            query = "with rr as (with tt as (select smgeometry from cir_seg where cisec_id in (select cirsec_id from cir_sec where circt_id = '" + circuit_code + "')) select node.smgeometry as geom from node inner join tt on st_intersects(tt.smgeometry, node.smgeometry) where node_type = (select enumlabel from pg_enum where enumtypid in ( select oid from pg_type where typname = 'node_types') and enumsortorder = 8)::node_types) select subf_name from substat inner join rr on st_intersects(rr.geom, substat.smgeometry)"
            cursor.execute(query)
            subs = []

            for a_s in cursor.fetchall():
                subs.append(a_s[0])

            begin_circuit , end_circuit = self.checkStartEndPoint(subs)
            self.dlg.beginPost_LE.setText(begin_circuit)
            self.dlg.endPost_LE.setText(end_circuit)
        except IndexError as e:
            return

    def set_tool_button_action(self):
        menu = QtWidgets.QMenu()
        menu.addAction('محاسبه', self.calculate_distance)
        menu.addAction('محاسبه و حذف نقاط قبلی',
                       self.calculate_distance_with_delete)
        menu.setStyleSheet('font: 10pt "B Nazanin";')
        self.dlg.calculate_BTN.setMenu(menu)

    def calculate_distance(self):
        length = self.dlg.doubleSpinBox.value()
        if length > float(self.dlg.circuitLentgh_LE.text()):
            self.iface.messageBar().pushMessage("Warning", "طول وارد شده از طول مدار بیشتر است",
                                                level=utils.Qgis.Warning, duration=10)
            return
        circuit_name = self.dlg.circuitchoice_CMB.currentText()
        circuit_code = circuit_name.split('کد:')[1].strip()
        cursor = self.conn.getConn().cursor()

        query = "with tt as (select st_linemerge(st_union(smgeometry)) as geom from cir_seg where cisec_id in (select cirsec_id from cir_sec where circt_id = '" + circuit_code + "')) select substat.subf_name from tt inner join substat on st_intersects(substat.smgeometry, st_startpoint(tt.geom))"
        cursor.execute(query)
        first_side = cursor.fetchone()[0]
        if self.dlg.source_RBTN.isChecked():
            first_side_sel = self.dlg.beginPost_LE.text()
        elif self.dlg.dest_RBTN.isChecked():
            first_side_sel = self.dlg.endPost_LE.text()
        else:
            self.iface.messageBar().pushMessage("Warning", "لطفا ابتدای مدار را مشخص نمایید", level=utils.Qgis.Warning,
                                                duration=10)
            return

        if first_side == first_side_sel:
            geom_part = str(length)
        else:
            geom_part = "st_length(geom) -" + str(length)

        query = "with rr as (with tt as (select st_linemerge(st_union(smgeometry)) as geom from cir_seg where cisec_id in (select cirsec_id from cir_sec where circt_id = '" + \
                circuit_code + "')) select ST_LineInterpolatePoint(geom,(" + geom_part + ")/st_length(geom)) as geo from tt) select st_x(geo), st_y(geo) from rr"

        cursor.execute(query)
        a_c = cursor.fetchone()
        coord_x = a_c[0]
        coord_y = a_c[1]
        self.dlg.x_geom_LE.setText('{0:.2f}'.format(coord_x))
        self.dlg.y_geom_LE.setText('{0:.2f}'.format(coord_y))
        canvas = self.iface.mapCanvas()
        rec_shape = self.get_marker_options()
        shape_ops = self.set_marker(rec_shape[0], rec_shape[1], rec_shape[2], rec_shape[3])
        m = QgsVertexMarker(canvas)
        m.setCenter(core.QgsPointXY(coord_x, coord_y))
        m.setColor(qgis.PyQt.QtGui.QColor(shape_ops[0]))
        m.setIconSize(int(shape_ops[1]))
        m.setPenWidth(int(shape_ops[2]))
        if shape_ops[3] == 'دایره':
            m.setIconType(QgsVertexMarker.ICON_CIRCLE)
        elif shape_ops[3] == 'ضربدر':
            m.setIconType(QgsVertexMarker.ICON_CROSS)
        elif shape_ops[3] == 'مثلث':
            m.setIconType(QgsVertexMarker.ICON_INVERTED_TRIANGLE)
        else:
            m.setIconType(QgsVertexMarker.ICON_RHOMBUS)
        self.dlg.markers.append(m)
        if self.dlg.zoomChk.isChecked():
            offset = 10
            zoomRectangle = core.QgsRectangle(coord_x - offset, coord_y - offset, coord_x + offset, coord_y + offset)
            canvas.setExtent(zoomRectangle)
        canvas.refresh()


    def set_marker(self, r_color, r_size, r_width, r_shape):
        color_dict = {'قرمز': 'red', 'آبی': 'blue', 'زرد': 'yellow', 'سبز': 'green', 'مشکی': 'black', 'سفید': 'white'}
        size = r_size[:2:]
        width = r_width
        color = color_dict[r_color]
        shape = r_shape
        return color, size, width, shape

    def calculate_distance_with_delete(self):
        DistRelay.clearMarkersList(self.dlg.markers)
        self.calculate_distance()