#QGIS Batch Saver Plugin
This plugin allow you to save multiple vector layers using a selection of file extensions in a configurable path.
